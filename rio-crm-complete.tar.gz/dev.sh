#!/bin/bash

# Rio CRM Development Startup Script
echo "🔧 Starting Rio CRM in Development Mode..."

# Set development environment variables
export PYTHONPATH="/home/runner/rio-crm/rio-crm-backend"
export FLASK_ENV="development"
export FLASK_DEBUG="True"
export HOST="0.0.0.0"
export PORT="5000"

# Function to start backend in development mode
start_backend_dev() {
    echo "🚀 Starting backend in development mode..."
    cd rio-crm-backend
    
    # Activate virtual environment
    if [ -d "venv" ]; then
        source venv/bin/activate
    else
        echo "❌ Virtual environment not found. Please run setup first."
        exit 1
    fi
    
    # Start Flask with hot reload
    python src/main.py &
    BACKEND_PID=$!
    echo "Backend started with PID: $BACKEND_PID"
    
    cd ..
}

# Function to start frontend in development mode
start_frontend_dev() {
    echo "🎨 Starting frontend in development mode..."
    cd rio-crm-frontend
    
    # Start Vite dev server
    if command -v pnpm >/dev/null 2>&1; then
        pnpm run dev --host &
    elif command -v npm >/dev/null 2>&1; then
        npm run dev -- --host &
    else
        echo "❌ Neither pnpm nor npm found!"
        exit 1
    fi
    
    FRONTEND_PID=$!
    echo "Frontend started with PID: $FRONTEND_PID"
    
    cd ..
}

# Function to handle cleanup on exit
cleanup() {
    echo "🛑 Shutting down development servers..."
    if [ ! -z "$BACKEND_PID" ]; then
        kill $BACKEND_PID 2>/dev/null
    fi
    if [ ! -z "$FRONTEND_PID" ]; then
        kill $FRONTEND_PID 2>/dev/null
    fi
    exit 0
}

# Set up signal handlers
trap cleanup SIGINT SIGTERM

# Main execution
main() {
    echo "🔧 Rio CRM Development Environment"
    echo "=================================="
    
    # Check if directories exist
    if [ ! -d "rio-crm-backend" ] || [ ! -d "rio-crm-frontend" ]; then
        echo "❌ Rio CRM directories not found!"
        exit 1
    fi
    
    # Start both backend and frontend
    start_backend_dev
    start_frontend_dev
    
    echo ""
    echo "✅ Development servers started!"
    echo "📱 Frontend: http://localhost:3000"
    echo "🔧 Backend API: http://localhost:5000"
    echo "📊 Health Check: http://localhost:5000/api/health"
    echo ""
    echo "Press Ctrl+C to stop both servers"
    
    # Wait for processes
    wait
}

# Run main function
main "$@"

