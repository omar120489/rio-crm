from flask import Blueprint, request, jsonify
from datetime import datetime
from src.models.crm_models import Contact, Company, Activity, Deal, db
from src.routes.auth import token_required

contacts_bp = Blueprint('contacts', __name__)

@contacts_bp.route('/contacts', methods=['GET'])
@token_required
def get_contacts(current_user):
    """Get all contacts with filtering and pagination"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        company_id = request.args.get('company_id', type=int)
        search = request.args.get('search')
        
        query = Contact.query
        
        # Apply filters
        if company_id:
            query = query.filter(Contact.company_id == company_id)
        
        if search:
            search_term = f"%{search}%"
            query = query.filter(
                db.or_(
                    Contact.first_name.ilike(search_term),
                    Contact.last_name.ilike(search_term),
                    Contact.email.ilike(search_term),
                    Contact.phone.ilike(search_term),
                    Contact.job_title.ilike(search_term)
                )
            )
        
        # Order by last_name, first_name
        query = query.order_by(Contact.last_name, Contact.first_name)
        
        # Paginate
        contacts = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        return jsonify({
            'contacts': [contact.to_dict() for contact in contacts.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': contacts.total,
                'pages': contacts.pages,
                'has_next': contacts.has_next,
                'has_prev': contacts.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch contacts', 'error': str(e)}), 500

@contacts_bp.route('/contacts', methods=['POST'])
@token_required
def create_contact(current_user):
    """Create a new contact"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['first_name', 'last_name', 'email']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'message': f'{field} is required'}), 400
        
        # Check if contact with email already exists
        existing_contact = Contact.query.filter_by(email=data['email']).first()
        if existing_contact:
            return jsonify({'message': 'Contact with this email already exists'}), 409
        
        # Handle company
        company_id = None
        if data.get('company_name'):
            company = Company.query.filter_by(name=data['company_name']).first()
            if not company:
                company = Company(name=data['company_name'])
                db.session.add(company)
                db.session.flush()  # Get the ID
            company_id = company.id
        elif data.get('company_id'):
            company_id = data['company_id']
        
        # Create contact
        contact = Contact(
            first_name=data['first_name'],
            last_name=data['last_name'],
            email=data['email'],
            phone=data.get('phone'),
            mobile=data.get('mobile'),
            job_title=data.get('job_title'),
            department=data.get('department'),
            company_id=company_id,
            is_primary=data.get('is_primary', False),
            linkedin_url=data.get('linkedin_url'),
            notes=data.get('notes')
        )
        
        db.session.add(contact)
        db.session.commit()
        
        return jsonify({
            'message': 'Contact created successfully',
            'contact': contact.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Failed to create contact', 'error': str(e)}), 500

@contacts_bp.route('/contacts/<int:contact_id>', methods=['GET'])
@token_required
def get_contact(current_user, contact_id):
    """Get a specific contact with related data"""
    try:
        contact = Contact.query.get_or_404(contact_id)
        
        # Get recent activities
        recent_activities = Activity.query.filter_by(contact_id=contact_id)\
            .order_by(Activity.created_at.desc())\
            .limit(10).all()
        
        # Get related deals
        deals = Deal.query.filter_by(primary_contact_id=contact_id).all()
        
        contact_data = contact.to_dict()
        contact_data['recent_activities'] = [activity.to_dict() for activity in recent_activities]
        contact_data['deals'] = [deal.to_dict() for deal in deals]
        
        return jsonify(contact_data), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch contact', 'error': str(e)}), 500

@contacts_bp.route('/contacts/<int:contact_id>', methods=['PUT'])
@token_required
def update_contact(current_user, contact_id):
    """Update a contact"""
    try:
        contact = Contact.query.get_or_404(contact_id)
        data = request.get_json()
        
        # Update fields
        if 'first_name' in data:
            contact.first_name = data['first_name']
        if 'last_name' in data:
            contact.last_name = data['last_name']
        if 'email' in data:
            # Check if email is already taken by another contact
            existing_contact = Contact.query.filter_by(email=data['email']).first()
            if existing_contact and existing_contact.id != contact.id:
                return jsonify({'message': 'Email already in use by another contact'}), 409
            contact.email = data['email']
        if 'phone' in data:
            contact.phone = data['phone']
        if 'mobile' in data:
            contact.mobile = data['mobile']
        if 'job_title' in data:
            contact.job_title = data['job_title']
        if 'department' in data:
            contact.department = data['department']
        if 'is_primary' in data:
            contact.is_primary = data['is_primary']
        if 'linkedin_url' in data:
            contact.linkedin_url = data['linkedin_url']
        if 'notes' in data:
            contact.notes = data['notes']
        
        # Handle company update
        if 'company_name' in data:
            if data['company_name']:
                company = Company.query.filter_by(name=data['company_name']).first()
                if not company:
                    company = Company(name=data['company_name'])
                    db.session.add(company)
                    db.session.flush()
                contact.company_id = company.id
            else:
                contact.company_id = None
        elif 'company_id' in data:
            contact.company_id = data['company_id']
        
        contact.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Contact updated successfully',
            'contact': contact.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Failed to update contact', 'error': str(e)}), 500

@contacts_bp.route('/contacts/<int:contact_id>', methods=['DELETE'])
@token_required
def delete_contact(current_user, contact_id):
    """Delete a contact"""
    try:
        contact = Contact.query.get_or_404(contact_id)
        
        # Check if contact has related deals
        related_deals = Deal.query.filter_by(primary_contact_id=contact_id).count()
        if related_deals > 0:
            return jsonify({
                'message': 'Cannot delete contact with related deals. Please reassign or delete deals first.'
            }), 400
        
        db.session.delete(contact)
        db.session.commit()
        
        return jsonify({'message': 'Contact deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Failed to delete contact', 'error': str(e)}), 500

@contacts_bp.route('/contacts/<int:contact_id>/activities', methods=['GET'])
@token_required
def get_contact_activities(current_user, contact_id):
    """Get all activities for a contact"""
    try:
        contact = Contact.query.get_or_404(contact_id)
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        activities = Activity.query.filter_by(contact_id=contact_id)\
            .order_by(Activity.created_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'activities': [activity.to_dict() for activity in activities.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': activities.total,
                'pages': activities.pages,
                'has_next': activities.has_next,
                'has_prev': activities.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch contact activities', 'error': str(e)}), 500

@contacts_bp.route('/contacts/<int:contact_id>/deals', methods=['GET'])
@token_required
def get_contact_deals(current_user, contact_id):
    """Get all deals for a contact"""
    try:
        contact = Contact.query.get_or_404(contact_id)
        
        deals = Deal.query.filter_by(primary_contact_id=contact_id)\
            .order_by(Deal.created_at.desc()).all()
        
        return jsonify({
            'deals': [deal.to_dict() for deal in deals]
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch contact deals', 'error': str(e)}), 500

@contacts_bp.route('/contacts/stats', methods=['GET'])
@token_required
def get_contact_stats(current_user):
    """Get contact statistics"""
    try:
        total_contacts = Contact.query.count()
        
        # Contacts by company
        contacts_with_company = Contact.query.filter(Contact.company_id.isnot(None)).count()
        contacts_without_company = total_contacts - contacts_with_company
        
        # Recent contacts (last 30 days)
        from datetime import timedelta
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        recent_contacts = Contact.query.filter(Contact.created_at >= thirty_days_ago).count()
        
        # Top companies by contact count
        top_companies = db.session.query(
            Company.name,
            db.func.count(Contact.id).label('contact_count')
        ).join(Contact).group_by(Company.id, Company.name)\
         .order_by(db.func.count(Contact.id).desc())\
         .limit(5).all()
        
        return jsonify({
            'total_contacts': total_contacts,
            'contacts_with_company': contacts_with_company,
            'contacts_without_company': contacts_without_company,
            'recent_contacts': recent_contacts,
            'top_companies': [
                {'name': company.name, 'contact_count': company.contact_count}
                for company in top_companies
            ]
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch contact stats', 'error': str(e)}), 500

