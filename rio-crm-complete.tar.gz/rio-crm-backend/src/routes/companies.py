from flask import Blueprint, request, jsonify
from datetime import datetime
from src.models.crm_models import Company, Contact, Lead, Deal, db
from src.routes.auth import token_required

companies_bp = Blueprint('companies', __name__)

@companies_bp.route('/companies', methods=['GET'])
@token_required
def get_companies(current_user):
    """Get all companies with filtering and pagination"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        industry = request.args.get('industry')
        search = request.args.get('search')
        
        query = Company.query
        
        # Apply filters
        if industry:
            query = query.filter(Company.industry == industry)
        
        if search:
            search_term = f"%{search}%"
            query = query.filter(
                db.or_(
                    Company.name.ilike(search_term),
                    Company.website.ilike(search_term),
                    Company.email.ilike(search_term),
                    Company.description.ilike(search_term)
                )
            )
        
        # Order by name
        query = query.order_by(Company.name)
        
        # Paginate
        companies = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        return jsonify({
            'companies': [company.to_dict() for company in companies.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': companies.total,
                'pages': companies.pages,
                'has_next': companies.has_next,
                'has_prev': companies.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch companies', 'error': str(e)}), 500

@companies_bp.route('/companies', methods=['POST'])
@token_required
def create_company(current_user):
    """Create a new company"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data.get('name'):
            return jsonify({'message': 'Company name is required'}), 400
        
        # Check if company with name already exists
        existing_company = Company.query.filter_by(name=data['name']).first()
        if existing_company:
            return jsonify({'message': 'Company with this name already exists'}), 409
        
        # Create company
        company = Company(
            name=data['name'],
            industry=data.get('industry'),
            website=data.get('website'),
            phone=data.get('phone'),
            email=data.get('email'),
            address=data.get('address'),
            city=data.get('city'),
            state=data.get('state'),
            country=data.get('country'),
            postal_code=data.get('postal_code'),
            annual_revenue=data.get('annual_revenue'),
            employee_count=data.get('employee_count'),
            description=data.get('description')
        )
        
        db.session.add(company)
        db.session.commit()
        
        return jsonify({
            'message': 'Company created successfully',
            'company': company.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Failed to create company', 'error': str(e)}), 500

@companies_bp.route('/companies/<int:company_id>', methods=['GET'])
@token_required
def get_company(current_user, company_id):
    """Get a specific company with related data"""
    try:
        company = Company.query.get_or_404(company_id)
        
        # Get related data
        contacts = Contact.query.filter_by(company_id=company_id).all()
        leads = Lead.query.filter_by(company_id=company_id).all()
        deals = Deal.query.filter_by(company_id=company_id).all()
        
        # Calculate company metrics
        total_deal_value = sum(float(deal.value) for deal in deals if deal.value)
        won_deals = [deal for deal in deals if deal.status.value == 'closed_won']
        won_deal_value = sum(float(deal.value) for deal in won_deals if deal.value)
        
        company_data = company.to_dict()
        company_data.update({
            'contacts': [contact.to_dict() for contact in contacts],
            'leads': [lead.to_dict() for lead in leads],
            'deals': [deal.to_dict() for deal in deals],
            'metrics': {
                'contact_count': len(contacts),
                'lead_count': len(leads),
                'deal_count': len(deals),
                'total_deal_value': total_deal_value,
                'won_deal_value': won_deal_value,
                'won_deal_count': len(won_deals)
            }
        })
        
        return jsonify(company_data), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch company', 'error': str(e)}), 500

@companies_bp.route('/companies/<int:company_id>', methods=['PUT'])
@token_required
def update_company(current_user, company_id):
    """Update a company"""
    try:
        company = Company.query.get_or_404(company_id)
        data = request.get_json()
        
        # Update fields
        if 'name' in data:
            # Check if name is already taken by another company
            existing_company = Company.query.filter_by(name=data['name']).first()
            if existing_company and existing_company.id != company.id:
                return jsonify({'message': 'Company name already in use'}), 409
            company.name = data['name']
        
        if 'industry' in data:
            company.industry = data['industry']
        if 'website' in data:
            company.website = data['website']
        if 'phone' in data:
            company.phone = data['phone']
        if 'email' in data:
            company.email = data['email']
        if 'address' in data:
            company.address = data['address']
        if 'city' in data:
            company.city = data['city']
        if 'state' in data:
            company.state = data['state']
        if 'country' in data:
            company.country = data['country']
        if 'postal_code' in data:
            company.postal_code = data['postal_code']
        if 'annual_revenue' in data:
            company.annual_revenue = data['annual_revenue']
        if 'employee_count' in data:
            company.employee_count = data['employee_count']
        if 'description' in data:
            company.description = data['description']
        
        company.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Company updated successfully',
            'company': company.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Failed to update company', 'error': str(e)}), 500

@companies_bp.route('/companies/<int:company_id>', methods=['DELETE'])
@token_required
def delete_company(current_user, company_id):
    """Delete a company"""
    try:
        company = Company.query.get_or_404(company_id)
        
        # Check if company has related records
        contact_count = Contact.query.filter_by(company_id=company_id).count()
        lead_count = Lead.query.filter_by(company_id=company_id).count()
        deal_count = Deal.query.filter_by(company_id=company_id).count()
        
        if contact_count > 0 or lead_count > 0 or deal_count > 0:
            return jsonify({
                'message': f'Cannot delete company with related records. Found {contact_count} contacts, {lead_count} leads, and {deal_count} deals.'
            }), 400
        
        db.session.delete(company)
        db.session.commit()
        
        return jsonify({'message': 'Company deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Failed to delete company', 'error': str(e)}), 500

@companies_bp.route('/companies/<int:company_id>/contacts', methods=['GET'])
@token_required
def get_company_contacts(current_user, company_id):
    """Get all contacts for a company"""
    try:
        company = Company.query.get_or_404(company_id)
        
        contacts = Contact.query.filter_by(company_id=company_id)\
            .order_by(Contact.last_name, Contact.first_name).all()
        
        return jsonify({
            'contacts': [contact.to_dict() for contact in contacts]
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch company contacts', 'error': str(e)}), 500

@companies_bp.route('/companies/<int:company_id>/leads', methods=['GET'])
@token_required
def get_company_leads(current_user, company_id):
    """Get all leads for a company"""
    try:
        company = Company.query.get_or_404(company_id)
        
        leads = Lead.query.filter_by(company_id=company_id)\
            .order_by(Lead.created_at.desc()).all()
        
        return jsonify({
            'leads': [lead.to_dict() for lead in leads]
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch company leads', 'error': str(e)}), 500

@companies_bp.route('/companies/<int:company_id>/deals', methods=['GET'])
@token_required
def get_company_deals(current_user, company_id):
    """Get all deals for a company"""
    try:
        company = Company.query.get_or_404(company_id)
        
        deals = Deal.query.filter_by(company_id=company_id)\
            .order_by(Deal.created_at.desc()).all()
        
        return jsonify({
            'deals': [deal.to_dict() for deal in deals]
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch company deals', 'error': str(e)}), 500

@companies_bp.route('/companies/stats', methods=['GET'])
@token_required
def get_company_stats(current_user):
    """Get company statistics"""
    try:
        total_companies = Company.query.count()
        
        # Companies by industry
        industry_stats = db.session.query(
            Company.industry,
            db.func.count(Company.id).label('count')
        ).filter(Company.industry.isnot(None))\
         .group_by(Company.industry)\
         .order_by(db.func.count(Company.id).desc())\
         .limit(10).all()
        
        # Recent companies (last 30 days)
        from datetime import timedelta
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        recent_companies = Company.query.filter(Company.created_at >= thirty_days_ago).count()
        
        # Top companies by deal value
        top_companies_by_value = db.session.query(
            Company.name,
            db.func.sum(Deal.value).label('total_value'),
            db.func.count(Deal.id).label('deal_count')
        ).join(Deal).group_by(Company.id, Company.name)\
         .order_by(db.func.sum(Deal.value).desc())\
         .limit(5).all()
        
        # Companies with most contacts
        top_companies_by_contacts = db.session.query(
            Company.name,
            db.func.count(Contact.id).label('contact_count')
        ).join(Contact).group_by(Company.id, Company.name)\
         .order_by(db.func.count(Contact.id).desc())\
         .limit(5).all()
        
        return jsonify({
            'total_companies': total_companies,
            'recent_companies': recent_companies,
            'industry_breakdown': [
                {'industry': stat.industry, 'count': stat.count}
                for stat in industry_stats
            ],
            'top_companies_by_value': [
                {
                    'name': company.name,
                    'total_value': float(company.total_value),
                    'deal_count': company.deal_count
                }
                for company in top_companies_by_value
            ],
            'top_companies_by_contacts': [
                {
                    'name': company.name,
                    'contact_count': company.contact_count
                }
                for company in top_companies_by_contacts
            ]
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch company stats', 'error': str(e)}), 500

@companies_bp.route('/companies/industries', methods=['GET'])
@token_required
def get_industries(current_user):
    """Get list of all industries"""
    try:
        industries = db.session.query(Company.industry)\
            .filter(Company.industry.isnot(None))\
            .distinct().order_by(Company.industry).all()
        
        return jsonify({
            'industries': [industry[0] for industry in industries]
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch industries', 'error': str(e)}), 500

