from flask import Blueprint, request, jsonify
from datetime import datetime
from src.models.crm_models import Lead, Company, User, Contact, db, LeadStatus
from src.routes.auth import token_required

leads_bp = Blueprint('leads', __name__)

@leads_bp.route('/leads', methods=['GET'])
@token_required
def get_leads(current_user):
    """Get all leads with filtering and pagination"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        status = request.args.get('status')
        assigned_user_id = request.args.get('assigned_user_id', type=int)
        search = request.args.get('search')
        
        query = Lead.query
        
        # Apply filters
        if status:
            query = query.filter(Lead.status == LeadStatus(status))
        
        if assigned_user_id:
            query = query.filter(Lead.assigned_user_id == assigned_user_id)
        
        if search:
            search_term = f"%{search}%"
            query = query.filter(
                db.or_(
                    Lead.first_name.ilike(search_term),
                    Lead.last_name.ilike(search_term),
                    Lead.email.ilike(search_term),
                    Lead.phone.ilike(search_term)
                )
            )
        
        # Order by created_at desc
        query = query.order_by(Lead.created_at.desc())
        
        # Paginate
        leads = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        return jsonify({
            'leads': [lead.to_dict() for lead in leads.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': leads.total,
                'pages': leads.pages,
                'has_next': leads.has_next,
                'has_prev': leads.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch leads', 'error': str(e)}), 500

@leads_bp.route('/leads', methods=['POST'])
@token_required
def create_lead(current_user):
    """Create a new lead"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['first_name', 'last_name', 'email']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'message': f'{field} is required'}), 400
        
        # Check if lead with email already exists
        existing_lead = Lead.query.filter_by(email=data['email']).first()
        if existing_lead:
            return jsonify({'message': 'Lead with this email already exists'}), 409
        
        # Handle company
        company_id = None
        if data.get('company_name'):
            company = Company.query.filter_by(name=data['company_name']).first()
            if not company:
                company = Company(name=data['company_name'])
                db.session.add(company)
                db.session.flush()  # Get the ID
            company_id = company.id
        elif data.get('company_id'):
            company_id = data['company_id']
        
        # Create lead
        lead = Lead(
            first_name=data['first_name'],
            last_name=data['last_name'],
            email=data['email'],
            phone=data.get('phone'),
            company_id=company_id,
            job_title=data.get('job_title'),
            status=LeadStatus(data.get('status', 'new')),
            source=data.get('source'),
            score=data.get('score', 0),
            assigned_user_id=data.get('assigned_user_id', current_user.id),
            notes=data.get('notes'),
            next_follow_up=datetime.fromisoformat(data['next_follow_up']) if data.get('next_follow_up') else None
        )
        
        db.session.add(lead)
        db.session.commit()
        
        return jsonify({
            'message': 'Lead created successfully',
            'lead': lead.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Failed to create lead', 'error': str(e)}), 500

@leads_bp.route('/leads/<int:lead_id>', methods=['GET'])
@token_required
def get_lead(current_user, lead_id):
    """Get a specific lead"""
    try:
        lead = Lead.query.get_or_404(lead_id)
        return jsonify(lead.to_dict()), 200
    except Exception as e:
        return jsonify({'message': 'Failed to fetch lead', 'error': str(e)}), 500

@leads_bp.route('/leads/<int:lead_id>', methods=['PUT'])
@token_required
def update_lead(current_user, lead_id):
    """Update a lead"""
    try:
        lead = Lead.query.get_or_404(lead_id)
        data = request.get_json()
        
        # Update fields
        if 'first_name' in data:
            lead.first_name = data['first_name']
        if 'last_name' in data:
            lead.last_name = data['last_name']
        if 'email' in data:
            # Check if email is already taken by another lead
            existing_lead = Lead.query.filter_by(email=data['email']).first()
            if existing_lead and existing_lead.id != lead.id:
                return jsonify({'message': 'Email already in use by another lead'}), 409
            lead.email = data['email']
        if 'phone' in data:
            lead.phone = data['phone']
        if 'job_title' in data:
            lead.job_title = data['job_title']
        if 'status' in data:
            lead.status = LeadStatus(data['status'])
        if 'source' in data:
            lead.source = data['source']
        if 'score' in data:
            lead.score = data['score']
        if 'assigned_user_id' in data:
            lead.assigned_user_id = data['assigned_user_id']
        if 'notes' in data:
            lead.notes = data['notes']
        if 'next_follow_up' in data:
            lead.next_follow_up = datetime.fromisoformat(data['next_follow_up']) if data['next_follow_up'] else None
        
        # Handle company update
        if 'company_name' in data:
            if data['company_name']:
                company = Company.query.filter_by(name=data['company_name']).first()
                if not company:
                    company = Company(name=data['company_name'])
                    db.session.add(company)
                    db.session.flush()
                lead.company_id = company.id
            else:
                lead.company_id = None
        elif 'company_id' in data:
            lead.company_id = data['company_id']
        
        lead.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Lead updated successfully',
            'lead': lead.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Failed to update lead', 'error': str(e)}), 500

@leads_bp.route('/leads/<int:lead_id>', methods=['DELETE'])
@token_required
def delete_lead(current_user, lead_id):
    """Delete a lead"""
    try:
        lead = Lead.query.get_or_404(lead_id)
        db.session.delete(lead)
        db.session.commit()
        
        return jsonify({'message': 'Lead deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Failed to delete lead', 'error': str(e)}), 500

@leads_bp.route('/leads/<int:lead_id>/convert', methods=['POST'])
@token_required
def convert_lead(current_user, lead_id):
    """Convert a lead to a contact"""
    try:
        lead = Lead.query.get_or_404(lead_id)
        
        if lead.status != LeadStatus.QUALIFIED:
            return jsonify({'message': 'Lead must be qualified before conversion'}), 400
        
        if lead.converted_to_contact_id:
            return jsonify({'message': 'Lead has already been converted'}), 400
        
        # Create contact from lead
        contact = Contact(
            first_name=lead.first_name,
            last_name=lead.last_name,
            email=lead.email,
            phone=lead.phone,
            job_title=lead.job_title,
            company_id=lead.company_id,
            notes=lead.notes
        )
        
        db.session.add(contact)
        db.session.flush()  # Get the contact ID
        
        # Update lead with conversion info
        lead.converted_to_contact_id = contact.id
        lead.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'message': 'Lead converted successfully',
            'contact': contact.to_dict(),
            'lead': lead.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Failed to convert lead', 'error': str(e)}), 500

@leads_bp.route('/leads/stats', methods=['GET'])
@token_required
def get_lead_stats(current_user):
    """Get lead statistics"""
    try:
        total_leads = Lead.query.count()
        new_leads = Lead.query.filter(Lead.status == LeadStatus.NEW).count()
        qualified_leads = Lead.query.filter(Lead.status == LeadStatus.QUALIFIED).count()
        converted_leads = Lead.query.filter(Lead.converted_to_contact_id.isnot(None)).count()
        
        # Leads by status
        status_counts = {}
        for status in LeadStatus:
            count = Lead.query.filter(Lead.status == status).count()
            status_counts[status.value] = count
        
        # Recent leads (last 30 days)
        from datetime import timedelta
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        recent_leads = Lead.query.filter(Lead.created_at >= thirty_days_ago).count()
        
        return jsonify({
            'total_leads': total_leads,
            'new_leads': new_leads,
            'qualified_leads': qualified_leads,
            'converted_leads': converted_leads,
            'conversion_rate': (converted_leads / total_leads * 100) if total_leads > 0 else 0,
            'status_breakdown': status_counts,
            'recent_leads': recent_leads
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch lead stats', 'error': str(e)}), 500

