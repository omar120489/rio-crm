from flask import Blueprint, request, jsonify
from datetime import datetime, timedelta
from src.models.crm_models import (
    User, Lead, Contact, Company, Deal, Activity, 
    db, LeadStatus, DealStatus, ActivityType
)
from src.routes.auth import token_required

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/dashboard/overview', methods=['GET'])
@token_required
def get_dashboard_overview(current_user):
    """Get dashboard overview with key metrics"""
    try:
        # Date range filter
        days = request.args.get('days', 30, type=int)
        start_date = datetime.utcnow() - timedelta(days=days)
        
        # Basic counts
        total_leads = Lead.query.count()
        total_contacts = Contact.query.count()
        total_companies = Company.query.count()
        total_deals = Deal.query.count()
        
        # Recent additions
        recent_leads = Lead.query.filter(Lead.created_at >= start_date).count()
        recent_contacts = Contact.query.filter(Contact.created_at >= start_date).count()
        recent_companies = Company.query.filter(Company.created_at >= start_date).count()
        recent_deals = Deal.query.filter(Deal.created_at >= start_date).count()
        
        # Deal metrics
        open_deals = Deal.query.filter(
            Deal.status.notin_([DealStatus.CLOSED_WON, DealStatus.CLOSED_LOST])
        ).count()
        won_deals = Deal.query.filter(Deal.status == DealStatus.CLOSED_WON).count()
        lost_deals = Deal.query.filter(Deal.status == DealStatus.CLOSED_LOST).count()
        
        # Revenue metrics
        total_revenue = db.session.query(db.func.sum(Deal.value))\
            .filter(Deal.status == DealStatus.CLOSED_WON).scalar() or 0
        
        pipeline_value = db.session.query(db.func.sum(Deal.value))\
            .filter(Deal.status.notin_([DealStatus.CLOSED_WON, DealStatus.CLOSED_LOST]))\
            .scalar() or 0
        
        # Calculate weighted pipeline
        weighted_pipeline = 0
        open_deals_query = Deal.query.filter(
            Deal.status.notin_([DealStatus.CLOSED_WON, DealStatus.CLOSED_LOST])
        ).all()
        for deal in open_deals_query:
            weighted_pipeline += deal.weighted_value
        
        # Activity metrics
        total_activities = Activity.query.count()
        completed_activities = Activity.query.filter(Activity.is_completed == True).count()
        overdue_activities = Activity.query.filter(
            Activity.is_completed == False,
            Activity.scheduled_at.isnot(None),
            Activity.scheduled_at < datetime.utcnow()
        ).count()
        
        # Lead conversion metrics
        qualified_leads = Lead.query.filter(Lead.status == LeadStatus.QUALIFIED).count()
        converted_leads = Lead.query.filter(Lead.converted_to_contact_id.isnot(None)).count()
        conversion_rate = (converted_leads / total_leads * 100) if total_leads > 0 else 0
        
        # Win rate
        closed_deals = won_deals + lost_deals
        win_rate = (won_deals / closed_deals * 100) if closed_deals > 0 else 0
        
        return jsonify({
            'period_days': days,
            'totals': {
                'leads': total_leads,
                'contacts': total_contacts,
                'companies': total_companies,
                'deals': total_deals,
                'activities': total_activities
            },
            'recent': {
                'leads': recent_leads,
                'contacts': recent_contacts,
                'companies': recent_companies,
                'deals': recent_deals
            },
            'deals': {
                'open': open_deals,
                'won': won_deals,
                'lost': lost_deals,
                'win_rate': round(win_rate, 2)
            },
            'revenue': {
                'total_revenue': float(total_revenue),
                'pipeline_value': float(pipeline_value),
                'weighted_pipeline': round(weighted_pipeline, 2)
            },
            'activities': {
                'total': total_activities,
                'completed': completed_activities,
                'overdue': overdue_activities,
                'completion_rate': round((completed_activities / total_activities * 100) if total_activities > 0 else 0, 2)
            },
            'leads': {
                'total': total_leads,
                'qualified': qualified_leads,
                'converted': converted_leads,
                'conversion_rate': round(conversion_rate, 2)
            }
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch dashboard overview', 'error': str(e)}), 500

@dashboard_bp.route('/dashboard/sales-pipeline', methods=['GET'])
@token_required
def get_sales_pipeline(current_user):
    """Get sales pipeline data"""
    try:
        owner_id = request.args.get('owner_id', type=int)
        
        query = Deal.query
        if owner_id:
            query = query.filter(Deal.owner_id == owner_id)
        
        # Pipeline by stage
        pipeline = {}
        total_value = 0
        total_weighted = 0
        
        for status in DealStatus:
            deals = query.filter(Deal.status == status).all()
            stage_value = sum(float(deal.value) for deal in deals if deal.value)
            stage_weighted = sum(deal.weighted_value for deal in deals)
            
            pipeline[status.value] = {
                'count': len(deals),
                'value': stage_value,
                'weighted_value': round(stage_weighted, 2),
                'deals': [deal.to_dict() for deal in deals]
            }
            
            total_value += stage_value
            total_weighted += stage_weighted
        
        # Top deals by value
        top_deals = query.order_by(Deal.value.desc()).limit(5).all()
        
        # Deals closing this month
        today = datetime.utcnow().date()
        month_start = today.replace(day=1)
        next_month = (month_start + timedelta(days=32)).replace(day=1)
        
        closing_this_month = query.filter(
            Deal.expected_close_date >= month_start,
            Deal.expected_close_date < next_month,
            Deal.status.notin_([DealStatus.CLOSED_WON, DealStatus.CLOSED_LOST])
        ).all()
        
        return jsonify({
            'pipeline': pipeline,
            'summary': {
                'total_value': round(total_value, 2),
                'total_weighted_value': round(total_weighted, 2),
                'total_deals': query.count()
            },
            'top_deals': [deal.to_dict() for deal in top_deals],
            'closing_this_month': [deal.to_dict() for deal in closing_this_month]
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch sales pipeline', 'error': str(e)}), 500

@dashboard_bp.route('/dashboard/activity-summary', methods=['GET'])
@token_required
def get_activity_summary(current_user):
    """Get activity summary for dashboard"""
    try:
        user_id = request.args.get('user_id', current_user.id, type=int)
        days = request.args.get('days', 7, type=int)
        
        start_date = datetime.utcnow() - timedelta(days=days)
        
        query = Activity.query.filter(Activity.user_id == user_id)
        
        # Activities by type
        type_summary = {}
        for activity_type in ActivityType:
            count = query.filter(Activity.type == activity_type).count()
            completed = query.filter(
                Activity.type == activity_type,
                Activity.is_completed == True
            ).count()
            
            type_summary[activity_type.value] = {
                'total': count,
                'completed': completed,
                'pending': count - completed
            }
        
        # Upcoming activities (next 7 days)
        upcoming = Activity.query.filter(
            Activity.user_id == user_id,
            Activity.is_completed == False,
            Activity.scheduled_at.isnot(None),
            Activity.scheduled_at >= datetime.utcnow(),
            Activity.scheduled_at <= datetime.utcnow() + timedelta(days=7)
        ).order_by(Activity.scheduled_at.asc()).limit(10).all()
        
        # Overdue activities
        overdue = Activity.query.filter(
            Activity.user_id == user_id,
            Activity.is_completed == False,
            Activity.scheduled_at.isnot(None),
            Activity.scheduled_at < datetime.utcnow()
        ).order_by(Activity.scheduled_at.desc()).limit(10).all()
        
        # Recent completed activities
        recent_completed = query.filter(
            Activity.is_completed == True,
            Activity.completed_at >= start_date
        ).order_by(Activity.completed_at.desc()).limit(10).all()
        
        return jsonify({
            'type_summary': type_summary,
            'upcoming': [activity.to_dict() for activity in upcoming],
            'overdue': [activity.to_dict() for activity in overdue],
            'recent_completed': [activity.to_dict() for activity in recent_completed]
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch activity summary', 'error': str(e)}), 500

@dashboard_bp.route('/dashboard/lead-funnel', methods=['GET'])
@token_required
def get_lead_funnel(current_user):
    """Get lead funnel data"""
    try:
        days = request.args.get('days', 30, type=int)
        start_date = datetime.utcnow() - timedelta(days=days)
        
        # Leads by status
        funnel = {}
        total_leads = 0
        
        for status in LeadStatus:
            count = Lead.query.filter(Lead.status == status).count()
            recent_count = Lead.query.filter(
                Lead.status == status,
                Lead.created_at >= start_date
            ).count()
            
            funnel[status.value] = {
                'total': count,
                'recent': recent_count
            }
            total_leads += count
        
        # Lead sources
        sources = db.session.query(
            Lead.source,
            db.func.count(Lead.id).label('count')
        ).filter(Lead.source.isnot(None))\
         .group_by(Lead.source)\
         .order_by(db.func.count(Lead.id).desc()).all()
        
        # Conversion metrics
        converted_leads = Lead.query.filter(Lead.converted_to_contact_id.isnot(None)).count()
        qualified_leads = Lead.query.filter(Lead.status == LeadStatus.QUALIFIED).count()
        
        # Lead scoring distribution
        score_ranges = [
            ('0-20', 0, 20),
            ('21-40', 21, 40),
            ('41-60', 41, 60),
            ('61-80', 61, 80),
            ('81-100', 81, 100)
        ]
        
        score_distribution = {}
        for range_name, min_score, max_score in score_ranges:
            count = Lead.query.filter(
                Lead.score >= min_score,
                Lead.score <= max_score
            ).count()
            score_distribution[range_name] = count
        
        return jsonify({
            'funnel': funnel,
            'total_leads': total_leads,
            'conversion_rate': round((converted_leads / total_leads * 100) if total_leads > 0 else 0, 2),
            'qualification_rate': round((qualified_leads / total_leads * 100) if total_leads > 0 else 0, 2),
            'sources': [
                {'source': source.source, 'count': source.count}
                for source in sources
            ],
            'score_distribution': score_distribution
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch lead funnel', 'error': str(e)}), 500

@dashboard_bp.route('/dashboard/revenue-trends', methods=['GET'])
@token_required
def get_revenue_trends(current_user):
    """Get revenue trends over time"""
    try:
        months = request.args.get('months', 12, type=int)
        
        # Calculate monthly revenue for the past N months
        monthly_revenue = []
        monthly_deals = []
        
        for i in range(months):
            # Calculate the start and end of each month
            today = datetime.utcnow().date()
            month_start = (today.replace(day=1) - timedelta(days=i*30)).replace(day=1)
            next_month = (month_start + timedelta(days=32)).replace(day=1)
            
            # Get won deals for this month
            won_deals = Deal.query.filter(
                Deal.status == DealStatus.CLOSED_WON,
                Deal.actual_close_date >= month_start,
                Deal.actual_close_date < next_month
            ).all()
            
            revenue = sum(float(deal.value) for deal in won_deals if deal.value)
            deal_count = len(won_deals)
            
            monthly_revenue.append({
                'month': month_start.strftime('%Y-%m'),
                'revenue': revenue,
                'deal_count': deal_count
            })
            
            monthly_deals.extend(won_deals)
        
        # Reverse to show oldest to newest
        monthly_revenue.reverse()
        
        # Calculate trends
        total_revenue = sum(item['revenue'] for item in monthly_revenue)
        total_deals = sum(item['deal_count'] for item in monthly_revenue)
        avg_deal_size = (total_revenue / total_deals) if total_deals > 0 else 0
        
        # Current month vs previous month
        current_month_revenue = monthly_revenue[-1]['revenue'] if monthly_revenue else 0
        previous_month_revenue = monthly_revenue[-2]['revenue'] if len(monthly_revenue) > 1 else 0
        
        revenue_growth = 0
        if previous_month_revenue > 0:
            revenue_growth = ((current_month_revenue - previous_month_revenue) / previous_month_revenue) * 100
        
        return jsonify({
            'monthly_revenue': monthly_revenue,
            'summary': {
                'total_revenue': round(total_revenue, 2),
                'total_deals': total_deals,
                'avg_deal_size': round(avg_deal_size, 2),
                'revenue_growth': round(revenue_growth, 2)
            }
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch revenue trends', 'error': str(e)}), 500

@dashboard_bp.route('/dashboard/team-performance', methods=['GET'])
@token_required
def get_team_performance(current_user):
    """Get team performance metrics"""
    try:
        # Get all sales reps
        sales_reps = User.query.filter(User.role.in_(['sales_rep', 'manager'])).all()
        
        team_stats = []
        
        for user in sales_reps:
            # User's deals
            user_deals = Deal.query.filter(Deal.owner_id == user.id).all()
            won_deals = [deal for deal in user_deals if deal.status == DealStatus.CLOSED_WON]
            open_deals = [deal for deal in user_deals if deal.status not in [DealStatus.CLOSED_WON, DealStatus.CLOSED_LOST]]
            
            # User's activities
            user_activities = Activity.query.filter(Activity.user_id == user.id).count()
            completed_activities = Activity.query.filter(
                Activity.user_id == user.id,
                Activity.is_completed == True
            ).count()
            
            # User's leads
            user_leads = Lead.query.filter(Lead.assigned_user_id == user.id).count()
            converted_leads = Lead.query.filter(
                Lead.assigned_user_id == user.id,
                Lead.converted_to_contact_id.isnot(None)
            ).count()
            
            # Calculate metrics
            total_revenue = sum(float(deal.value) for deal in won_deals if deal.value)
            pipeline_value = sum(float(deal.value) for deal in open_deals if deal.value)
            
            team_stats.append({
                'user': user.to_dict(),
                'metrics': {
                    'total_deals': len(user_deals),
                    'won_deals': len(won_deals),
                    'open_deals': len(open_deals),
                    'total_revenue': round(total_revenue, 2),
                    'pipeline_value': round(pipeline_value, 2),
                    'total_activities': user_activities,
                    'completed_activities': completed_activities,
                    'activity_completion_rate': round((completed_activities / user_activities * 100) if user_activities > 0 else 0, 2),
                    'total_leads': user_leads,
                    'converted_leads': converted_leads,
                    'lead_conversion_rate': round((converted_leads / user_leads * 100) if user_leads > 0 else 0, 2)
                }
            })
        
        # Sort by total revenue
        team_stats.sort(key=lambda x: x['metrics']['total_revenue'], reverse=True)
        
        return jsonify({
            'team_performance': team_stats
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch team performance', 'error': str(e)}), 500

