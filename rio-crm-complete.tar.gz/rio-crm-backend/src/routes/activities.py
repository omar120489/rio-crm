from flask import Blueprint, request, jsonify
from datetime import datetime
from src.models.crm_models import Activity, Contact, Deal, User, db, ActivityType
from src.routes.auth import token_required

activities_bp = Blueprint('activities', __name__)

@activities_bp.route('/activities', methods=['GET'])
@token_required
def get_activities(current_user):
    """Get all activities with filtering and pagination"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        activity_type = request.args.get('type')
        user_id = request.args.get('user_id', type=int)
        contact_id = request.args.get('contact_id', type=int)
        deal_id = request.args.get('deal_id', type=int)
        is_completed = request.args.get('is_completed')
        search = request.args.get('search')
        
        query = Activity.query
        
        # Apply filters
        if activity_type:
            query = query.filter(Activity.type == ActivityType(activity_type))
        
        if user_id:
            query = query.filter(Activity.user_id == user_id)
        
        if contact_id:
            query = query.filter(Activity.contact_id == contact_id)
        
        if deal_id:
            query = query.filter(Activity.deal_id == deal_id)
        
        if is_completed is not None:
            completed = is_completed.lower() == 'true'
            query = query.filter(Activity.is_completed == completed)
        
        if search:
            search_term = f"%{search}%"
            query = query.filter(
                db.or_(
                    Activity.subject.ilike(search_term),
                    Activity.description.ilike(search_term),
                    Activity.outcome.ilike(search_term)
                )
            )
        
        # Order by scheduled_at desc, created_at desc
        query = query.order_by(Activity.scheduled_at.desc(), Activity.created_at.desc())
        
        # Paginate
        activities = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        return jsonify({
            'activities': [activity.to_dict() for activity in activities.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': activities.total,
                'pages': activities.pages,
                'has_next': activities.has_next,
                'has_prev': activities.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch activities', 'error': str(e)}), 500

@activities_bp.route('/activities', methods=['POST'])
@token_required
def create_activity(current_user):
    """Create a new activity"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['type', 'subject']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'message': f'{field} is required'}), 400
        
        # Validate contact if provided
        if data.get('contact_id'):
            contact = Contact.query.get(data['contact_id'])
            if not contact:
                return jsonify({'message': 'Contact not found'}), 404
        
        # Validate deal if provided
        if data.get('deal_id'):
            deal = Deal.query.get(data['deal_id'])
            if not deal:
                return jsonify({'message': 'Deal not found'}), 404
        
        # Parse dates
        scheduled_at = None
        if data.get('scheduled_at'):
            scheduled_at = datetime.fromisoformat(data['scheduled_at'])
        
        completed_at = None
        if data.get('completed_at'):
            completed_at = datetime.fromisoformat(data['completed_at'])
        
        # Create activity
        activity = Activity(
            type=ActivityType(data['type']),
            subject=data['subject'],
            description=data.get('description'),
            scheduled_at=scheduled_at,
            completed_at=completed_at,
            duration_minutes=data.get('duration_minutes'),
            user_id=data.get('user_id', current_user.id),
            contact_id=data.get('contact_id'),
            deal_id=data.get('deal_id'),
            is_completed=data.get('is_completed', False),
            outcome=data.get('outcome'),
            next_action=data.get('next_action')
        )
        
        db.session.add(activity)
        db.session.commit()
        
        return jsonify({
            'message': 'Activity created successfully',
            'activity': activity.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Failed to create activity', 'error': str(e)}), 500

@activities_bp.route('/activities/<int:activity_id>', methods=['GET'])
@token_required
def get_activity(current_user, activity_id):
    """Get a specific activity"""
    try:
        activity = Activity.query.get_or_404(activity_id)
        return jsonify(activity.to_dict()), 200
    except Exception as e:
        return jsonify({'message': 'Failed to fetch activity', 'error': str(e)}), 500

@activities_bp.route('/activities/<int:activity_id>', methods=['PUT'])
@token_required
def update_activity(current_user, activity_id):
    """Update an activity"""
    try:
        activity = Activity.query.get_or_404(activity_id)
        data = request.get_json()
        
        # Update fields
        if 'type' in data:
            activity.type = ActivityType(data['type'])
        if 'subject' in data:
            activity.subject = data['subject']
        if 'description' in data:
            activity.description = data['description']
        if 'scheduled_at' in data:
            if data['scheduled_at']:
                activity.scheduled_at = datetime.fromisoformat(data['scheduled_at'])
            else:
                activity.scheduled_at = None
        if 'completed_at' in data:
            if data['completed_at']:
                activity.completed_at = datetime.fromisoformat(data['completed_at'])
            else:
                activity.completed_at = None
        if 'duration_minutes' in data:
            activity.duration_minutes = data['duration_minutes']
        if 'user_id' in data:
            # Validate user exists
            user = User.query.get(data['user_id'])
            if not user:
                return jsonify({'message': 'User not found'}), 404
            activity.user_id = data['user_id']
        if 'contact_id' in data:
            if data['contact_id']:
                contact = Contact.query.get(data['contact_id'])
                if not contact:
                    return jsonify({'message': 'Contact not found'}), 404
            activity.contact_id = data['contact_id']
        if 'deal_id' in data:
            if data['deal_id']:
                deal = Deal.query.get(data['deal_id'])
                if not deal:
                    return jsonify({'message': 'Deal not found'}), 404
            activity.deal_id = data['deal_id']
        if 'is_completed' in data:
            activity.is_completed = data['is_completed']
            # Set completed_at if marking as completed
            if data['is_completed'] and not activity.completed_at:
                activity.completed_at = datetime.utcnow()
            elif not data['is_completed']:
                activity.completed_at = None
        if 'outcome' in data:
            activity.outcome = data['outcome']
        if 'next_action' in data:
            activity.next_action = data['next_action']
        
        activity.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Activity updated successfully',
            'activity': activity.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Failed to update activity', 'error': str(e)}), 500

@activities_bp.route('/activities/<int:activity_id>', methods=['DELETE'])
@token_required
def delete_activity(current_user, activity_id):
    """Delete an activity"""
    try:
        activity = Activity.query.get_or_404(activity_id)
        db.session.delete(activity)
        db.session.commit()
        
        return jsonify({'message': 'Activity deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Failed to delete activity', 'error': str(e)}), 500

@activities_bp.route('/activities/<int:activity_id>/complete', methods=['POST'])
@token_required
def complete_activity(current_user, activity_id):
    """Mark an activity as completed"""
    try:
        activity = Activity.query.get_or_404(activity_id)
        data = request.get_json() or {}
        
        activity.is_completed = True
        activity.completed_at = datetime.utcnow()
        
        if data.get('outcome'):
            activity.outcome = data['outcome']
        if data.get('next_action'):
            activity.next_action = data['next_action']
        if data.get('duration_minutes'):
            activity.duration_minutes = data['duration_minutes']
        
        activity.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Activity marked as completed',
            'activity': activity.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Failed to complete activity', 'error': str(e)}), 500

@activities_bp.route('/activities/upcoming', methods=['GET'])
@token_required
def get_upcoming_activities(current_user):
    """Get upcoming activities for the current user"""
    try:
        user_id = request.args.get('user_id', current_user.id, type=int)
        limit = request.args.get('limit', 10, type=int)
        
        activities = Activity.query.filter(
            Activity.user_id == user_id,
            Activity.is_completed == False,
            Activity.scheduled_at.isnot(None),
            Activity.scheduled_at >= datetime.utcnow()
        ).order_by(Activity.scheduled_at.asc()).limit(limit).all()
        
        return jsonify({
            'activities': [activity.to_dict() for activity in activities]
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch upcoming activities', 'error': str(e)}), 500

@activities_bp.route('/activities/overdue', methods=['GET'])
@token_required
def get_overdue_activities(current_user):
    """Get overdue activities for the current user"""
    try:
        user_id = request.args.get('user_id', current_user.id, type=int)
        limit = request.args.get('limit', 10, type=int)
        
        activities = Activity.query.filter(
            Activity.user_id == user_id,
            Activity.is_completed == False,
            Activity.scheduled_at.isnot(None),
            Activity.scheduled_at < datetime.utcnow()
        ).order_by(Activity.scheduled_at.desc()).limit(limit).all()
        
        return jsonify({
            'activities': [activity.to_dict() for activity in activities]
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch overdue activities', 'error': str(e)}), 500

@activities_bp.route('/activities/stats', methods=['GET'])
@token_required
def get_activity_stats(current_user):
    """Get activity statistics"""
    try:
        user_id = request.args.get('user_id', type=int)
        
        query = Activity.query
        if user_id:
            query = query.filter(Activity.user_id == user_id)
        
        total_activities = query.count()
        completed_activities = query.filter(Activity.is_completed == True).count()
        pending_activities = total_activities - completed_activities
        
        # Overdue activities
        overdue_activities = query.filter(
            Activity.is_completed == False,
            Activity.scheduled_at.isnot(None),
            Activity.scheduled_at < datetime.utcnow()
        ).count()
        
        # Activities by type
        type_counts = {}
        for activity_type in ActivityType:
            count = query.filter(Activity.type == activity_type).count()
            type_counts[activity_type.value] = count
        
        # Recent activities (last 30 days)
        from datetime import timedelta
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        recent_activities = query.filter(Activity.created_at >= thirty_days_ago).count()
        
        # Completion rate
        completion_rate = (completed_activities / total_activities * 100) if total_activities > 0 else 0
        
        return jsonify({
            'total_activities': total_activities,
            'completed_activities': completed_activities,
            'pending_activities': pending_activities,
            'overdue_activities': overdue_activities,
            'completion_rate': round(completion_rate, 2),
            'type_breakdown': type_counts,
            'recent_activities': recent_activities
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch activity stats', 'error': str(e)}), 500

