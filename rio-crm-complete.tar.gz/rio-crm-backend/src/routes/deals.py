from flask import Blueprint, request, jsonify
from datetime import datetime, date
from src.models.crm_models import Deal, Company, Contact, User, Activity, db, DealStatus
from src.routes.auth import token_required

deals_bp = Blueprint('deals', __name__)

@deals_bp.route('/deals', methods=['GET'])
@token_required
def get_deals(current_user):
    """Get all deals with filtering and pagination"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        status = request.args.get('status')
        owner_id = request.args.get('owner_id', type=int)
        company_id = request.args.get('company_id', type=int)
        search = request.args.get('search')
        
        query = Deal.query
        
        # Apply filters
        if status:
            query = query.filter(Deal.status == DealStatus(status))
        
        if owner_id:
            query = query.filter(Deal.owner_id == owner_id)
        
        if company_id:
            query = query.filter(Deal.company_id == company_id)
        
        if search:
            search_term = f"%{search}%"
            query = query.filter(
                db.or_(
                    Deal.name.ilike(search_term),
                    Deal.description.ilike(search_term)
                )
            )
        
        # Order by expected_close_date, created_at desc
        query = query.order_by(Deal.expected_close_date.asc(), Deal.created_at.desc())
        
        # Paginate
        deals = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        return jsonify({
            'deals': [deal.to_dict() for deal in deals.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': deals.total,
                'pages': deals.pages,
                'has_next': deals.has_next,
                'has_prev': deals.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch deals', 'error': str(e)}), 500

@deals_bp.route('/deals', methods=['POST'])
@token_required
def create_deal(current_user):
    """Create a new deal"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'value', 'company_id']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'message': f'{field} is required'}), 400
        
        # Validate company exists
        company = Company.query.get(data['company_id'])
        if not company:
            return jsonify({'message': 'Company not found'}), 404
        
        # Validate contact if provided
        primary_contact_id = data.get('primary_contact_id')
        if primary_contact_id:
            contact = Contact.query.get(primary_contact_id)
            if not contact:
                return jsonify({'message': 'Contact not found'}), 404
            if contact.company_id != data['company_id']:
                return jsonify({'message': 'Contact must belong to the specified company'}), 400
        
        # Parse dates
        expected_close_date = None
        if data.get('expected_close_date'):
            expected_close_date = datetime.fromisoformat(data['expected_close_date']).date()
        
        # Create deal
        deal = Deal(
            name=data['name'],
            description=data.get('description'),
            value=data['value'],
            probability=data.get('probability', 0),
            status=DealStatus(data.get('status', 'prospecting')),
            company_id=data['company_id'],
            primary_contact_id=primary_contact_id,
            owner_id=data.get('owner_id', current_user.id),
            expected_close_date=expected_close_date,
            source=data.get('source'),
            notes=data.get('notes')
        )
        
        db.session.add(deal)
        db.session.commit()
        
        return jsonify({
            'message': 'Deal created successfully',
            'deal': deal.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Failed to create deal', 'error': str(e)}), 500

@deals_bp.route('/deals/<int:deal_id>', methods=['GET'])
@token_required
def get_deal(current_user, deal_id):
    """Get a specific deal with related data"""
    try:
        deal = Deal.query.get_or_404(deal_id)
        
        # Get recent activities
        recent_activities = Activity.query.filter_by(deal_id=deal_id)\
            .order_by(Activity.created_at.desc())\
            .limit(10).all()
        
        deal_data = deal.to_dict()
        deal_data['recent_activities'] = [activity.to_dict() for activity in recent_activities]
        
        return jsonify(deal_data), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch deal', 'error': str(e)}), 500

@deals_bp.route('/deals/<int:deal_id>', methods=['PUT'])
@token_required
def update_deal(current_user, deal_id):
    """Update a deal"""
    try:
        deal = Deal.query.get_or_404(deal_id)
        data = request.get_json()
        
        # Update fields
        if 'name' in data:
            deal.name = data['name']
        if 'description' in data:
            deal.description = data['description']
        if 'value' in data:
            deal.value = data['value']
        if 'probability' in data:
            deal.probability = max(0, min(100, data['probability']))  # Ensure 0-100 range
        if 'status' in data:
            old_status = deal.status
            new_status = DealStatus(data['status'])
            deal.status = new_status
            
            # Set actual close date if deal is closed
            if new_status in [DealStatus.CLOSED_WON, DealStatus.CLOSED_LOST] and old_status not in [DealStatus.CLOSED_WON, DealStatus.CLOSED_LOST]:
                deal.actual_close_date = date.today()
            elif new_status not in [DealStatus.CLOSED_WON, DealStatus.CLOSED_LOST]:
                deal.actual_close_date = None
        
        if 'company_id' in data:
            # Validate company exists
            company = Company.query.get(data['company_id'])
            if not company:
                return jsonify({'message': 'Company not found'}), 404
            deal.company_id = data['company_id']
            
            # Clear primary contact if it doesn't belong to new company
            if deal.primary_contact_id:
                contact = Contact.query.get(deal.primary_contact_id)
                if contact and contact.company_id != data['company_id']:
                    deal.primary_contact_id = None
        
        if 'primary_contact_id' in data:
            if data['primary_contact_id']:
                contact = Contact.query.get(data['primary_contact_id'])
                if not contact:
                    return jsonify({'message': 'Contact not found'}), 404
                if contact.company_id != deal.company_id:
                    return jsonify({'message': 'Contact must belong to the deal company'}), 400
            deal.primary_contact_id = data['primary_contact_id']
        
        if 'owner_id' in data:
            # Validate owner exists
            owner = User.query.get(data['owner_id'])
            if not owner:
                return jsonify({'message': 'Owner not found'}), 404
            deal.owner_id = data['owner_id']
        
        if 'expected_close_date' in data:
            if data['expected_close_date']:
                deal.expected_close_date = datetime.fromisoformat(data['expected_close_date']).date()
            else:
                deal.expected_close_date = None
        
        if 'source' in data:
            deal.source = data['source']
        if 'notes' in data:
            deal.notes = data['notes']
        
        deal.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Deal updated successfully',
            'deal': deal.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Failed to update deal', 'error': str(e)}), 500

@deals_bp.route('/deals/<int:deal_id>', methods=['DELETE'])
@token_required
def delete_deal(current_user, deal_id):
    """Delete a deal"""
    try:
        deal = Deal.query.get_or_404(deal_id)
        db.session.delete(deal)
        db.session.commit()
        
        return jsonify({'message': 'Deal deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Failed to delete deal', 'error': str(e)}), 500

@deals_bp.route('/deals/<int:deal_id>/activities', methods=['GET'])
@token_required
def get_deal_activities(current_user, deal_id):
    """Get all activities for a deal"""
    try:
        deal = Deal.query.get_or_404(deal_id)
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        activities = Activity.query.filter_by(deal_id=deal_id)\
            .order_by(Activity.created_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'activities': [activity.to_dict() for activity in activities.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': activities.total,
                'pages': activities.pages,
                'has_next': activities.has_next,
                'has_prev': activities.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch deal activities', 'error': str(e)}), 500

@deals_bp.route('/deals/pipeline', methods=['GET'])
@token_required
def get_pipeline(current_user):
    """Get deals grouped by pipeline stage"""
    try:
        owner_id = request.args.get('owner_id', type=int)
        
        query = Deal.query
        if owner_id:
            query = query.filter(Deal.owner_id == owner_id)
        
        # Group deals by status
        pipeline = {}
        for status in DealStatus:
            deals = query.filter(Deal.status == status).all()
            pipeline[status.value] = {
                'deals': [deal.to_dict() for deal in deals],
                'count': len(deals),
                'total_value': sum(float(deal.value) for deal in deals if deal.value),
                'weighted_value': sum(deal.weighted_value for deal in deals)
            }
        
        return jsonify(pipeline), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch pipeline', 'error': str(e)}), 500

@deals_bp.route('/deals/stats', methods=['GET'])
@token_required
def get_deal_stats(current_user):
    """Get deal statistics"""
    try:
        total_deals = Deal.query.count()
        open_deals = Deal.query.filter(
            Deal.status.notin_([DealStatus.CLOSED_WON, DealStatus.CLOSED_LOST])
        ).count()
        won_deals = Deal.query.filter(Deal.status == DealStatus.CLOSED_WON).count()
        lost_deals = Deal.query.filter(Deal.status == DealStatus.CLOSED_LOST).count()
        
        # Calculate total values
        total_value = db.session.query(db.func.sum(Deal.value)).scalar() or 0
        won_value = db.session.query(db.func.sum(Deal.value))\
            .filter(Deal.status == DealStatus.CLOSED_WON).scalar() or 0
        pipeline_value = db.session.query(db.func.sum(Deal.value))\
            .filter(Deal.status.notin_([DealStatus.CLOSED_WON, DealStatus.CLOSED_LOST]))\
            .scalar() or 0
        
        # Calculate weighted pipeline value
        weighted_pipeline = 0
        open_deals_query = Deal.query.filter(
            Deal.status.notin_([DealStatus.CLOSED_WON, DealStatus.CLOSED_LOST])
        ).all()
        for deal in open_deals_query:
            weighted_pipeline += deal.weighted_value
        
        # Win rate
        closed_deals = won_deals + lost_deals
        win_rate = (won_deals / closed_deals * 100) if closed_deals > 0 else 0
        
        # Average deal size
        avg_deal_size = (total_value / total_deals) if total_deals > 0 else 0
        avg_won_deal_size = (won_value / won_deals) if won_deals > 0 else 0
        
        # Recent deals (last 30 days)
        from datetime import timedelta
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        recent_deals = Deal.query.filter(Deal.created_at >= thirty_days_ago).count()
        
        # Deals by status
        status_counts = {}
        for status in DealStatus:
            count = Deal.query.filter(Deal.status == status).count()
            status_counts[status.value] = count
        
        return jsonify({
            'total_deals': total_deals,
            'open_deals': open_deals,
            'won_deals': won_deals,
            'lost_deals': lost_deals,
            'win_rate': round(win_rate, 2),
            'total_value': float(total_value),
            'won_value': float(won_value),
            'pipeline_value': float(pipeline_value),
            'weighted_pipeline_value': round(weighted_pipeline, 2),
            'avg_deal_size': round(float(avg_deal_size), 2),
            'avg_won_deal_size': round(float(avg_won_deal_size), 2),
            'recent_deals': recent_deals,
            'status_breakdown': status_counts
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to fetch deal stats', 'error': str(e)}), 500

