#!/usr/bin/env python3
"""
Database migration script for Rio CRM
Handles database schema updates and data migrations
"""

import os
import sys
import sqlite3
from datetime import datetime

# Add the parent directory to the path so we can import our modules
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.models.crm_models import db
from src.database.config import DatabaseConfig

class Migration:
    """Base migration class"""
    
    def __init__(self, version, description):
        self.version = version
        self.description = description
        self.timestamp = datetime.now()
    
    def up(self, connection):
        """Apply migration"""
        raise NotImplementedError("Subclasses must implement up() method")
    
    def down(self, connection):
        """Rollback migration"""
        raise NotImplementedError("Subclasses must implement down() method")

class Migration001_InitialSchema(Migration):
    """Initial database schema migration"""
    
    def __init__(self):
        super().__init__("001", "Initial database schema")
    
    def up(self, connection):
        """Create initial schema"""
        # This migration is handled by SQLAlchemy's create_all()
        # We just need to ensure the migration tracking table exists
        connection.execute("""
            CREATE TABLE IF NOT EXISTS migrations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                version VARCHAR(10) NOT NULL UNIQUE,
                description TEXT,
                applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        connection.commit()
    
    def down(self, connection):
        """Drop all tables"""
        # Get all table names
        cursor = connection.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]
        
        # Drop all tables except sqlite_sequence
        for table in tables:
            if table != 'sqlite_sequence':
                connection.execute(f"DROP TABLE IF EXISTS {table}")
        
        connection.commit()

class Migration002_AddIndexes(Migration):
    """Add database indexes for performance"""
    
    def __init__(self):
        super().__init__("002", "Add database indexes")
    
    def up(self, connection):
        """Add indexes"""
        indexes = [
            "CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)",
            "CREATE INDEX IF NOT EXISTS idx_users_username ON users(username)",
            "CREATE INDEX IF NOT EXISTS idx_leads_email ON leads(email)",
            "CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status)",
            "CREATE INDEX IF NOT EXISTS idx_leads_assigned_user ON leads(assigned_user_id)",
            "CREATE INDEX IF NOT EXISTS idx_contacts_email ON contacts(email)",
            "CREATE INDEX IF NOT EXISTS idx_contacts_company ON contacts(company_id)",
            "CREATE INDEX IF NOT EXISTS idx_deals_status ON deals(status)",
            "CREATE INDEX IF NOT EXISTS idx_deals_owner ON deals(owner_id)",
            "CREATE INDEX IF NOT EXISTS idx_deals_company ON deals(company_id)",
            "CREATE INDEX IF NOT EXISTS idx_activities_user ON activities(user_id)",
            "CREATE INDEX IF NOT EXISTS idx_activities_contact ON activities(contact_id)",
            "CREATE INDEX IF NOT EXISTS idx_activities_deal ON activities(deal_id)",
            "CREATE INDEX IF NOT EXISTS idx_activities_scheduled ON activities(scheduled_at)",
            "CREATE INDEX IF NOT EXISTS idx_companies_name ON companies(name)",
        ]
        
        for index_sql in indexes:
            connection.execute(index_sql)
        
        connection.commit()
    
    def down(self, connection):
        """Drop indexes"""
        indexes = [
            "DROP INDEX IF EXISTS idx_users_email",
            "DROP INDEX IF EXISTS idx_users_username",
            "DROP INDEX IF EXISTS idx_leads_email",
            "DROP INDEX IF EXISTS idx_leads_status",
            "DROP INDEX IF EXISTS idx_leads_assigned_user",
            "DROP INDEX IF EXISTS idx_contacts_email",
            "DROP INDEX IF EXISTS idx_contacts_company",
            "DROP INDEX IF EXISTS idx_deals_status",
            "DROP INDEX IF EXISTS idx_deals_owner",
            "DROP INDEX IF EXISTS idx_deals_company",
            "DROP INDEX IF EXISTS idx_activities_user",
            "DROP INDEX IF EXISTS idx_activities_contact",
            "DROP INDEX IF EXISTS idx_activities_deal",
            "DROP INDEX IF EXISTS idx_activities_scheduled",
            "DROP INDEX IF EXISTS idx_companies_name",
        ]
        
        for index_sql in indexes:
            connection.execute(index_sql)
        
        connection.commit()

class MigrationManager:
    """Manages database migrations"""
    
    def __init__(self, database_path=None):
        if database_path is None:
            database_path = os.path.join(os.path.dirname(__file__), 'app.db')
        self.database_path = database_path
        self.migrations = [
            Migration001_InitialSchema(),
            Migration002_AddIndexes(),
        ]
    
    def get_connection(self):
        """Get database connection"""
        return sqlite3.connect(self.database_path)
    
    def get_applied_migrations(self):
        """Get list of applied migrations"""
        conn = self.get_connection()
        try:
            cursor = conn.execute("SELECT version FROM migrations ORDER BY version")
            return [row[0] for row in cursor.fetchall()]
        except sqlite3.OperationalError:
            # migrations table doesn't exist yet
            return []
        finally:
            conn.close()
    
    def apply_migration(self, migration):
        """Apply a single migration"""
        conn = self.get_connection()
        try:
            print(f"Applying migration {migration.version}: {migration.description}")
            migration.up(conn)
            
            # Record migration as applied
            conn.execute(
                "INSERT INTO migrations (version, description) VALUES (?, ?)",
                (migration.version, migration.description)
            )
            conn.commit()
            print(f"Migration {migration.version} applied successfully")
            
        except Exception as e:
            conn.rollback()
            print(f"Error applying migration {migration.version}: {e}")
            raise
        finally:
            conn.close()
    
    def rollback_migration(self, migration):
        """Rollback a single migration"""
        conn = self.get_connection()
        try:
            print(f"Rolling back migration {migration.version}: {migration.description}")
            migration.down(conn)
            
            # Remove migration record
            conn.execute("DELETE FROM migrations WHERE version = ?", (migration.version,))
            conn.commit()
            print(f"Migration {migration.version} rolled back successfully")
            
        except Exception as e:
            conn.rollback()
            print(f"Error rolling back migration {migration.version}: {e}")
            raise
        finally:
            conn.close()
    
    def migrate(self):
        """Apply all pending migrations"""
        applied = self.get_applied_migrations()
        pending = [m for m in self.migrations if m.version not in applied]
        
        if not pending:
            print("No pending migrations")
            return
        
        print(f"Applying {len(pending)} pending migrations...")
        for migration in pending:
            self.apply_migration(migration)
        
        print("All migrations applied successfully!")
    
    def rollback(self, target_version=None):
        """Rollback migrations to target version"""
        applied = self.get_applied_migrations()
        
        if target_version is None:
            # Rollback last migration
            if not applied:
                print("No migrations to rollback")
                return
            target_version = applied[-2] if len(applied) > 1 else None
        
        # Find migrations to rollback
        to_rollback = []
        for version in reversed(applied):
            if target_version is None or version > target_version:
                migration = next((m for m in self.migrations if m.version == version), None)
                if migration:
                    to_rollback.append(migration)
            else:
                break
        
        if not to_rollback:
            print("No migrations to rollback")
            return
        
        print(f"Rolling back {len(to_rollback)} migrations...")
        for migration in to_rollback:
            self.rollback_migration(migration)
        
        print("Rollback completed successfully!")
    
    def status(self):
        """Show migration status"""
        applied = self.get_applied_migrations()
        
        print("Migration Status:")
        print("-" * 50)
        
        for migration in self.migrations:
            status = "APPLIED" if migration.version in applied else "PENDING"
            print(f"{migration.version}: {migration.description} [{status}]")
        
        print(f"\nTotal migrations: {len(self.migrations)}")
        print(f"Applied: {len(applied)}")
        print(f"Pending: {len(self.migrations) - len(applied)}")

def main():
    """Main migration script"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Rio CRM Database Migration Tool')
    parser.add_argument('command', choices=['migrate', 'rollback', 'status'], 
                       help='Migration command to execute')
    parser.add_argument('--target', help='Target migration version for rollback')
    parser.add_argument('--database', help='Database file path')
    
    args = parser.parse_args()
    
    manager = MigrationManager(args.database)
    
    if args.command == 'migrate':
        manager.migrate()
    elif args.command == 'rollback':
        manager.rollback(args.target)
    elif args.command == 'status':
        manager.status()

if __name__ == '__main__':
    main()

