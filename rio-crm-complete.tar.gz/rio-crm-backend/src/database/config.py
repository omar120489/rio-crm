import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from src.models.crm_models import db

class DatabaseConfig:
    """Database configuration class"""
    
    def __init__(self, app=None):
        self.app = app
        if app is not None:
            self.init_app(app)
    
    def init_app(self, app):
        """Initialize database configuration with Flask app"""
        # Database configuration
        database_path = os.path.join(os.path.dirname(__file__), 'app.db')
        app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{database_path}'
        app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
        app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
            'pool_pre_ping': True,
            'pool_recycle': 300,
        }
        
        # Initialize database
        db.init_app(app)
        
        # Create tables if they don't exist
        with app.app_context():
            db.create_all()
    
    @staticmethod
    def get_database_url():
        """Get database URL for external connections"""
        return os.environ.get('DATABASE_URL', 'sqlite:///app.db')
    
    @staticmethod
    def create_engine_from_url(database_url=None):
        """Create SQLAlchemy engine from URL"""
        if database_url is None:
            database_url = DatabaseConfig.get_database_url()
        
        return create_engine(
            database_url,
            pool_pre_ping=True,
            pool_recycle=300,
            echo=os.environ.get('SQL_DEBUG', 'false').lower() == 'true'
        )
    
    @staticmethod
    def create_session(engine=None):
        """Create database session"""
        if engine is None:
            engine = DatabaseConfig.create_engine_from_url()
        
        Session = sessionmaker(bind=engine)
        return Session()

# Database utility functions
def init_database_with_app(app):
    """Initialize database with Flask app context"""
    config = DatabaseConfig()
    config.init_app(app)
    return config

def reset_database(app):
    """Reset database - drop all tables and recreate"""
    with app.app_context():
        db.drop_all()
        db.create_all()
        print("Database reset successfully!")

def backup_database(backup_path=None):
    """Create database backup"""
    if backup_path is None:
        from datetime import datetime
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_path = f'backup_{timestamp}.db'
    
    import shutil
    database_path = os.path.join(os.path.dirname(__file__), 'app.db')
    
    if os.path.exists(database_path):
        shutil.copy2(database_path, backup_path)
        print(f"Database backed up to: {backup_path}")
        return backup_path
    else:
        print("Database file not found!")
        return None

def restore_database(backup_path):
    """Restore database from backup"""
    import shutil
    database_path = os.path.join(os.path.dirname(__file__), 'app.db')
    
    if os.path.exists(backup_path):
        shutil.copy2(backup_path, database_path)
        print(f"Database restored from: {backup_path}")
        return True
    else:
        print("Backup file not found!")
        return False

