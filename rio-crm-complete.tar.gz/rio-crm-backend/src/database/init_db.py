import os
import sqlite3
from datetime import datetime, date
from werkzeug.security import generate_password_hash
from src.models.crm_models import db, User, Company, Contact, Lead, Deal, Activity, LeadStatus, DealStatus, ActivityType

def init_database(app):
    """Initialize the database with tables and seed data"""
    with app.app_context():
        # Create all tables
        db.create_all()
        
        # Check if data already exists
        if User.query.first():
            print("Database already initialized with data")
            return
        
        print("Initializing database with seed data...")
        
        # Create users
        users_data = [
            {
                'username': 'admin',
                'email': 'admin@riocr.com',
                'password': 'admin123',
                'first_name': 'Admin',
                'last_name': 'User',
                'role': 'admin',
                'is_active': True
            },
            {
                'username': 'sales_rep',
                'email': 'sales@riocr.com',
                'password': 'sales123',
                'first_name': 'Sales',
                'last_name': 'Representative',
                'role': 'sales_rep',
                'is_active': True
            },
            {
                'username': 'manager',
                'email': 'manager@riocr.com',
                'password': 'manager123',
                'first_name': 'Sales',
                'last_name': 'Manager',
                'role': 'manager',
                'is_active': True
            },
            {
                'username': 'support',
                'email': 'support@riocr.com',
                'password': 'support123',
                'first_name': 'Customer',
                'last_name': 'Support',
                'role': 'support',
                'is_active': True
            }
        ]
        
        users = []
        for user_data in users_data:
            user = User(
                username=user_data['username'],
                email=user_data['email'],
                password_hash=generate_password_hash(user_data['password']),
                first_name=user_data['first_name'],
                last_name=user_data['last_name'],
                role=user_data['role'],
                is_active=user_data['is_active']
            )
            db.session.add(user)
            users.append(user)
        
        db.session.flush()  # Get user IDs
        
        # Create companies
        companies_data = [
            {
                'name': 'Acme Corporation',
                'industry': 'Technology',
                'website': 'https://acme.com',
                'phone': '+1-555-0101',
                'email': 'info@acme.com',
                'address': '123 Tech Street',
                'city': 'San Francisco',
                'state': 'CA',
                'country': 'USA',
                'postal_code': '94105',
                'annual_revenue': 5000000,
                'employee_count': 150,
                'description': 'Leading technology solutions provider'
            },
            {
                'name': 'Global Industries Inc',
                'industry': 'Manufacturing',
                'website': 'https://globalind.com',
                'phone': '+1-555-0102',
                'email': 'contact@globalind.com',
                'address': '456 Industrial Ave',
                'city': 'Detroit',
                'state': 'MI',
                'country': 'USA',
                'postal_code': '48201',
                'annual_revenue': 25000000,
                'employee_count': 500,
                'description': 'Global manufacturing and distribution company'
            },
            {
                'name': 'StartupXYZ',
                'industry': 'Software',
                'website': 'https://startupxyz.com',
                'phone': '+1-555-0103',
                'email': 'hello@startupxyz.com',
                'address': '789 Innovation Blvd',
                'city': 'Austin',
                'state': 'TX',
                'country': 'USA',
                'postal_code': '73301',
                'annual_revenue': 500000,
                'employee_count': 25,
                'description': 'Innovative software startup'
            },
            {
                'name': 'Enterprise Solutions Ltd',
                'industry': 'Consulting',
                'website': 'https://enterprisesol.com',
                'phone': '+1-555-0104',
                'email': 'info@enterprisesol.com',
                'address': '321 Business Center',
                'city': 'New York',
                'state': 'NY',
                'country': 'USA',
                'postal_code': '10001',
                'annual_revenue': 10000000,
                'employee_count': 200,
                'description': 'Enterprise consulting and solutions'
            }
        ]
        
        companies = []
        for company_data in companies_data:
            company = Company(**company_data)
            db.session.add(company)
            companies.append(company)
        
        db.session.flush()  # Get company IDs
        
        # Create contacts
        contacts_data = [
            {
                'first_name': 'John',
                'last_name': 'Smith',
                'email': 'john.smith@acme.com',
                'phone': '+1-555-1001',
                'mobile': '+1-555-2001',
                'job_title': 'CTO',
                'department': 'Technology',
                'company_id': companies[0].id,
                'is_primary': True,
                'linkedin_url': 'https://linkedin.com/in/johnsmith',
                'notes': 'Key decision maker for technology purchases'
            },
            {
                'first_name': 'Sarah',
                'last_name': 'Johnson',
                'email': 'sarah.johnson@acme.com',
                'phone': '+1-555-1002',
                'job_title': 'VP Sales',
                'department': 'Sales',
                'company_id': companies[0].id,
                'is_primary': False,
                'notes': 'Interested in sales automation tools'
            },
            {
                'first_name': 'Mike',
                'last_name': 'Wilson',
                'email': 'mike.wilson@globalind.com',
                'phone': '+1-555-1003',
                'job_title': 'Operations Manager',
                'department': 'Operations',
                'company_id': companies[1].id,
                'is_primary': True,
                'notes': 'Looking for process optimization solutions'
            },
            {
                'first_name': 'Emily',
                'last_name': 'Davis',
                'email': 'emily.davis@startupxyz.com',
                'phone': '+1-555-1004',
                'job_title': 'CEO',
                'department': 'Executive',
                'company_id': companies[2].id,
                'is_primary': True,
                'notes': 'Startup founder, budget conscious'
            },
            {
                'first_name': 'Robert',
                'last_name': 'Brown',
                'email': 'robert.brown@enterprisesol.com',
                'phone': '+1-555-1005',
                'job_title': 'Director of IT',
                'department': 'IT',
                'company_id': companies[3].id,
                'is_primary': True,
                'notes': 'Enterprise IT decision maker'
            }
        ]
        
        contacts = []
        for contact_data in contacts_data:
            contact = Contact(**contact_data)
            db.session.add(contact)
            contacts.append(contact)
        
        db.session.flush()  # Get contact IDs
        
        # Create leads
        leads_data = [
            {
                'first_name': 'Alex',
                'last_name': 'Thompson',
                'email': 'alex.thompson@newcompany.com',
                'phone': '+1-555-3001',
                'company_name': 'New Company Inc',
                'job_title': 'IT Manager',
                'status': LeadStatus.NEW,
                'source': 'Website',
                'score': 75,
                'assigned_user_id': users[1].id,  # sales_rep
                'notes': 'Interested in CRM solution, downloaded whitepaper'
            },
            {
                'first_name': 'Lisa',
                'last_name': 'Garcia',
                'email': 'lisa.garcia@techcorp.com',
                'phone': '+1-555-3002',
                'company_name': 'TechCorp Solutions',
                'job_title': 'VP Operations',
                'status': LeadStatus.QUALIFIED,
                'source': 'Referral',
                'score': 85,
                'assigned_user_id': users[1].id,  # sales_rep
                'notes': 'Qualified lead, ready for demo'
            },
            {
                'first_name': 'David',
                'last_name': 'Lee',
                'email': 'david.lee@innovate.com',
                'phone': '+1-555-3003',
                'company_name': 'Innovate Labs',
                'job_title': 'Founder',
                'status': LeadStatus.CONTACTED,
                'source': 'LinkedIn',
                'score': 60,
                'assigned_user_id': users[2].id,  # manager
                'notes': 'Initial contact made, follow-up scheduled'
            },
            {
                'first_name': 'Jennifer',
                'last_name': 'White',
                'email': 'jennifer.white@growth.com',
                'phone': '+1-555-3004',
                'company_name': 'Growth Partners',
                'job_title': 'Director',
                'status': LeadStatus.QUALIFIED,
                'source': 'Trade Show',
                'score': 45,
                'assigned_user_id': users[1].id,  # sales_rep
                'notes': 'Long-term opportunity, needs nurturing'
            }
        ]
        
        leads = []
        for lead_data in leads_data:
            lead = Lead(**lead_data)
            db.session.add(lead)
            leads.append(lead)
        
        db.session.flush()  # Get lead IDs
        
        # Create deals
        deals_data = [
            {
                'name': 'Acme CRM Implementation',
                'description': 'Full CRM system implementation for Acme Corporation',
                'value': 50000,
                'probability': 75,
                'status': DealStatus.PROPOSAL,
                'company_id': companies[0].id,
                'primary_contact_id': contacts[0].id,
                'owner_id': users[1].id,  # sales_rep
                'expected_close_date': date(2024, 3, 15),
                'source': 'Inbound Lead',
                'notes': 'Large implementation, high value opportunity'
            },
            {
                'name': 'Global Industries Automation',
                'description': 'Sales automation tools for Global Industries',
                'value': 75000,
                'probability': 60,
                'status': DealStatus.NEGOTIATION,
                'company_id': companies[1].id,
                'primary_contact_id': contacts[2].id,
                'owner_id': users[1].id,  # sales_rep
                'expected_close_date': date(2024, 4, 1),
                'source': 'Cold Outreach',
                'notes': 'In negotiation phase, price sensitive'
            },
            {
                'name': 'StartupXYZ Basic Package',
                'description': 'Basic CRM package for startup',
                'value': 5000,
                'probability': 90,
                'status': DealStatus.CLOSED_WON,
                'company_id': companies[2].id,
                'primary_contact_id': contacts[3].id,
                'owner_id': users[2].id,  # manager
                'expected_close_date': date(2024, 1, 15),
                'actual_close_date': date(2024, 1, 12),
                'source': 'Referral',
                'notes': 'Quick win, startup package'
            },
            {
                'name': 'Enterprise Solutions Upgrade',
                'description': 'Enterprise CRM upgrade and training',
                'value': 100000,
                'probability': 40,
                'status': DealStatus.PROSPECTING,
                'company_id': companies[3].id,
                'primary_contact_id': contacts[4].id,
                'owner_id': users[2].id,  # manager
                'expected_close_date': date(2024, 6, 30),
                'source': 'Existing Customer',
                'notes': 'Large enterprise deal, long sales cycle'
            }
        ]
        
        deals = []
        for deal_data in deals_data:
            deal = Deal(**deal_data)
            db.session.add(deal)
            deals.append(deal)
        
        db.session.flush()  # Get deal IDs
        
        # Create activities
        activities_data = [
            {
                'type': ActivityType.CALL,
                'subject': 'Initial discovery call with John Smith',
                'description': 'Discussed current CRM needs and pain points',
                'scheduled_at': datetime(2024, 2, 15, 10, 0),
                'completed_at': datetime(2024, 2, 15, 10, 30),
                'duration_minutes': 30,
                'user_id': users[1].id,  # sales_rep
                'contact_id': contacts[0].id,
                'deal_id': deals[0].id,
                'is_completed': True,
                'outcome': 'Positive response, interested in demo',
                'next_action': 'Schedule product demo'
            },
            {
                'type': ActivityType.EMAIL,
                'subject': 'Follow-up email to Sarah Johnson',
                'description': 'Sent product information and case studies',
                'scheduled_at': datetime(2024, 2, 16, 9, 0),
                'completed_at': datetime(2024, 2, 16, 9, 15),
                'duration_minutes': 15,
                'user_id': users[1].id,  # sales_rep
                'contact_id': contacts[1].id,
                'deal_id': deals[0].id,
                'is_completed': True,
                'outcome': 'Email sent with attachments',
                'next_action': 'Wait for response'
            },
            {
                'type': ActivityType.MEETING,
                'subject': 'Product demo for Acme team',
                'description': 'Comprehensive product demonstration',
                'scheduled_at': datetime(2024, 2, 20, 14, 0),
                'duration_minutes': 60,
                'user_id': users[1].id,  # sales_rep
                'contact_id': contacts[0].id,
                'deal_id': deals[0].id,
                'is_completed': False,
                'next_action': 'Prepare demo environment'
            },
            {
                'type': ActivityType.CALL,
                'subject': 'Check-in call with Mike Wilson',
                'description': 'Regular check-in on project status',
                'scheduled_at': datetime(2024, 2, 18, 11, 0),
                'duration_minutes': 20,
                'user_id': users[1].id,  # sales_rep
                'contact_id': contacts[2].id,
                'deal_id': deals[1].id,
                'is_completed': False,
                'next_action': 'Discuss timeline and next steps'
            },
            {
                'type': ActivityType.TASK,
                'subject': 'Prepare proposal for Enterprise Solutions',
                'description': 'Create detailed proposal document',
                'scheduled_at': datetime(2024, 2, 25, 9, 0),
                'duration_minutes': 120,
                'user_id': users[2].id,  # manager
                'deal_id': deals[3].id,
                'is_completed': False,
                'next_action': 'Review with legal team'
            }
        ]
        
        for activity_data in activities_data:
            activity = Activity(**activity_data)
            db.session.add(activity)
        
        # Commit all changes
        db.session.commit()
        
        print("Database initialized successfully!")
        print(f"Created {len(users)} users")
        print(f"Created {len(companies)} companies")
        print(f"Created {len(contacts)} contacts")
        print(f"Created {len(leads)} leads")
        print(f"Created {len(deals)} deals")
        print(f"Created {len(activities_data)} activities")

if __name__ == '__main__':
    from src.main import app
    init_database(app)

