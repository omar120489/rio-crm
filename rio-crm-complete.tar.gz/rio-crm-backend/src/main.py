import os
import sys
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory, jsonify
from flask_cors import CORS
from src.models.crm_models import db
from src.database.config import DatabaseConfig
from src.routes.auth import auth_bp
from src.routes.user import user_bp
from src.routes.leads import leads_bp
from src.routes.contacts import contacts_bp
from src.routes.deals import deals_bp
from src.routes.companies import companies_bp
from src.routes.activities import activities_bp
from src.routes.dashboard import dashboard_bp

def create_app(config_name='development'):
    """Application factory pattern"""
    app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))

    # Load configuration from environment
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'rio-crm-secret-key-change-in-production')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}")
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = os.getenv('SQLALCHEMY_TRACK_MODIFICATIONS', 'False').lower() == 'true'
    app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', 'jwt-secret-key-change-in-production')
    app.config['JWT_ACCESS_TOKEN_EXPIRES'] = int(os.getenv('JWT_ACCESS_TOKEN_EXPIRES', 3600))
    app.config['JWT_REFRESH_TOKEN_EXPIRES'] = int(os.getenv('JWT_REFRESH_TOKEN_EXPIRES', 2592000))

    # Enable CORS for all routes
    cors_origins = os.getenv('CORS_ORIGINS', '*')
    if cors_origins == '*':
        CORS(app, origins="*", methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"])
    else:
        origins_list = [origin.strip() for origin in cors_origins.split(',')]
        CORS(app, origins=origins_list, methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"])

    # Initialize database
    db.init_app(app)

    # Register blueprints
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(user_bp, url_prefix='/api')
    app.register_blueprint(leads_bp, url_prefix='/api')
    app.register_blueprint(contacts_bp, url_prefix='/api')
    app.register_blueprint(deals_bp, url_prefix='/api')
    app.register_blueprint(companies_bp, url_prefix='/api')
    app.register_blueprint(activities_bp, url_prefix='/api')
    app.register_blueprint(dashboard_bp, url_prefix='/api')

    # Create database tables and initialize with seed data
    with app.app_context():
        db.create_all()
        
        # Initialize with seed data if database is empty
        from src.models.crm_models import User
        if not User.query.first():
            try:
                from src.database.init_db import init_database
                init_database(app)
            except Exception as e:
                print(f"Warning: Could not initialize seed data: {e}")

    @app.route('/', defaults={'path': ''})
    @app.route('/<path:path>')
    def serve(path):
        """Serve static files and handle SPA routing"""
        static_folder_path = app.static_folder
        if static_folder_path is None:
            return jsonify({"message": "Static folder not configured"}), 404

        if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
            return send_from_directory(static_folder_path, path)
        else:
            index_path = os.path.join(static_folder_path, 'index.html')
            if os.path.exists(index_path):
                return send_from_directory(static_folder_path, 'index.html')
            else:
                return jsonify({"message": "Frontend not built. Please build the React app first."}), 404

    @app.errorhandler(404)
    def not_found(error):
        """Handle 404 errors"""
        return jsonify({"message": "Resource not found"}), 404

    @app.errorhandler(500)
    def internal_error(error):
        """Handle 500 errors"""
        db.session.rollback()
        return jsonify({"message": "Internal server error"}), 500

    @app.route('/api/health', methods=['GET'])
    def health_check():
        """Health check endpoint"""
        return jsonify({
            "status": "healthy", 
            "message": "Rio CRM API is running",
            "version": "1.0.0",
            "environment": os.getenv('FLASK_ENV', 'production')
        }), 200

    @app.route('/api/info', methods=['GET'])
    def api_info():
        """API information endpoint"""
        return jsonify({
            "name": "Rio CRM API",
            "version": "1.0.0",
            "description": "Customer Relationship Management System API",
            "endpoints": {
                "auth": "/api/auth",
                "users": "/api/users",
                "leads": "/api/leads",
                "contacts": "/api/contacts",
                "deals": "/api/deals",
                "companies": "/api/companies",
                "activities": "/api/activities",
                "dashboard": "/api/dashboard"
            },
            "documentation": "/api/docs" if os.getenv('ENABLE_API_DOCS', 'False').lower() == 'true' else None
        }), 200

    return app

# Create the application instance
app = create_app()

if __name__ == '__main__':
    host = os.getenv('HOST', '0.0.0.0')
    port = int(os.getenv('PORT', 5000))
    debug = os.getenv('FLASK_DEBUG', 'False').lower() == 'true'
    
    print(f"Starting Rio CRM API server...")
    print(f"Environment: {os.getenv('FLASK_ENV', 'production')}")
    print(f"Debug mode: {debug}")
    print(f"Host: {host}")
    print(f"Port: {port}")
    print(f"Database: {os.getenv('DATABASE_URL', 'sqlite:///app.db')}")
    
    app.run(host=host, port=port, debug=debug)

