#!/bin/bash

# Rio CRM Setup Script
echo "🔧 Setting up Rio CRM Application..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to check system requirements
check_requirements() {
    print_status "Checking system requirements..."
    
    # Check Python
    if command_exists python3; then
        PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
        print_success "Python found: $PYTHON_VERSION"
    else
        print_error "Python 3 is required but not found!"
        exit 1
    fi
    
    # Check Node.js
    if command_exists node; then
        NODE_VERSION=$(node --version)
        print_success "Node.js found: $NODE_VERSION"
    else
        print_error "Node.js is required but not found!"
        exit 1
    fi
    
    # Check package managers
    if command_exists pnpm; then
        PNPM_VERSION=$(pnpm --version)
        print_success "pnpm found: $PNPM_VERSION"
        PACKAGE_MANAGER="pnpm"
    elif command_exists npm; then
        NPM_VERSION=$(npm --version)
        print_success "npm found: $NPM_VERSION"
        PACKAGE_MANAGER="npm"
    else
        print_error "Neither pnpm nor npm found!"
        exit 1
    fi
}

# Function to setup backend
setup_backend() {
    print_status "Setting up backend..."
    
    if [ ! -d "rio-crm-backend" ]; then
        print_error "Backend directory not found!"
        exit 1
    fi
    
    cd rio-crm-backend
    
    # Create virtual environment
    if [ ! -d "venv" ]; then
        print_status "Creating Python virtual environment..."
        python3 -m venv venv
        print_success "Virtual environment created"
    else
        print_warning "Virtual environment already exists"
    fi
    
    # Activate virtual environment
    source venv/bin/activate
    
    # Upgrade pip
    print_status "Upgrading pip..."
    pip install --upgrade pip
    
    # Install dependencies
    if [ -f "requirements.txt" ]; then
        print_status "Installing Python dependencies..."
        pip install -r requirements.txt
        print_success "Python dependencies installed"
    else
        print_warning "requirements.txt not found, installing basic dependencies..."
        pip install flask flask-sqlalchemy flask-cors pyjwt python-dotenv werkzeug
    fi
    
    # Create necessary directories
    mkdir -p src/static
    mkdir -p src/database
    mkdir -p logs
    
    # Set up environment file
    if [ ! -f ".env" ]; then
        if [ -f ".env.example" ]; then
            cp .env.example .env
            print_success "Environment file created from example"
        else
            print_warning "No environment file found"
        fi
    fi
    
    cd ..
}

# Function to setup frontend
setup_frontend() {
    print_status "Setting up frontend..."
    
    if [ ! -d "rio-crm-frontend" ]; then
        print_error "Frontend directory not found!"
        exit 1
    fi
    
    cd rio-crm-frontend
    
    # Install dependencies
    print_status "Installing Node.js dependencies..."
    if [ "$PACKAGE_MANAGER" = "pnpm" ]; then
        pnpm install
    else
        npm install
    fi
    print_success "Node.js dependencies installed"
    
    cd ..
}

# Function to initialize database
setup_database() {
    print_status "Setting up database..."
    
    cd rio-crm-backend
    source venv/bin/activate
    
    # Run database initialization
    print_status "Initializing database with seed data..."
    python -c "
try:
    from src.main import app
    from src.database.init_db import init_database
    init_database(app)
    print('✅ Database initialized successfully')
except Exception as e:
    print(f'❌ Database initialization failed: {e}')
    exit(1)
"
    
    if [ $? -eq 0 ]; then
        print_success "Database setup completed"
    else
        print_error "Database setup failed"
        exit 1
    fi
    
    cd ..
}

# Function to run tests
run_tests() {
    print_status "Running basic tests..."
    
    # Test backend
    cd rio-crm-backend
    source venv/bin/activate
    
    print_status "Testing backend health..."
    python -c "
import sys
sys.path.insert(0, 'src')
try:
    from main import app
    with app.test_client() as client:
        response = client.get('/api/health')
        if response.status_code == 200:
            print('✅ Backend health check passed')
        else:
            print(f'❌ Backend health check failed: {response.status_code}')
            exit(1)
except Exception as e:
    print(f'❌ Backend test failed: {e}')
    exit(1)
"
    
    cd ..
    
    # Test frontend build
    cd rio-crm-frontend
    print_status "Testing frontend build..."
    
    if [ "$PACKAGE_MANAGER" = "pnpm" ]; then
        pnpm run build
    else
        npm run build
    fi
    
    if [ $? -eq 0 ]; then
        print_success "Frontend build test passed"
    else
        print_error "Frontend build test failed"
        exit 1
    fi
    
    cd ..
}

# Function to create project documentation
create_docs() {
    print_status "Creating project documentation..."
    
    cat > README.md << 'EOF'
# Rio CRM - Customer Relationship Management System

A modern, full-stack CRM application built with React and Flask.

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- Node.js 16+
- npm or pnpm

### Setup
```bash
# Run the setup script
./setup.sh

# Start development servers
./dev.sh

# Or start production server
./run.sh
```

### Access
- Frontend: http://localhost:3000 (development)
- Backend API: http://localhost:5000
- Health Check: http://localhost:5000/api/health

### Default Login Credentials
- Admin: admin@riocr.com / admin123
- Sales Rep: sales@riocr.com / sales123
- Manager: manager@riocr.com / manager123

## 📁 Project Structure

```
rio-crm/
├── rio-crm-backend/          # Flask backend
│   ├── src/
│   │   ├── models/           # Database models
│   │   ├── routes/           # API routes
│   │   ├── database/         # Database utilities
│   │   └── main.py           # Application entry point
│   ├── venv/                 # Python virtual environment
│   └── requirements.txt      # Python dependencies
├── rio-crm-frontend/         # React frontend
│   ├── src/
│   │   ├── components/       # React components
│   │   ├── pages/            # Page components
│   │   ├── contexts/         # React contexts
│   │   └── lib/              # Utilities and API client
│   └── package.json          # Node.js dependencies
├── run.sh                    # Production startup script
├── dev.sh                    # Development startup script
└── setup.sh                  # Initial setup script
```

## 🔧 Development

### Backend Development
```bash
cd rio-crm-backend
source venv/bin/activate
python src/main.py
```

### Frontend Development
```bash
cd rio-crm-frontend
pnpm run dev
```

### Database Management
```bash
cd rio-crm-backend
source venv/bin/activate

# Run migrations
python src/database/migrate.py migrate

# Check migration status
python src/database/migrate.py status

# Reset database
python -c "from src.main import app; from src.database.config import reset_database; reset_database(app)"
```

## 📊 Features

- **Dashboard**: Analytics and key metrics
- **Leads Management**: Track and qualify leads
- **Contacts Management**: Manage customer contacts
- **Deals Pipeline**: Track sales opportunities
- **Companies**: Manage company accounts
- **Activities**: Schedule and track tasks
- **Authentication**: Role-based access control

## 🛠️ Technology Stack

### Backend
- Flask (Python web framework)
- SQLAlchemy (ORM)
- SQLite (Database)
- JWT (Authentication)
- Flask-CORS (Cross-origin requests)

### Frontend
- React 18 (UI framework)
- Vite (Build tool)
- Tailwind CSS (Styling)
- shadcn/ui (UI components)
- React Router (Routing)
- React Query (Data fetching)
- Recharts (Charts)

## 🚀 Deployment

### Replit Deployment
This project is configured for easy deployment on Replit:

1. Import the project to Replit
2. The `.replit` and `replit.nix` files will configure the environment
3. Click "Run" to start the application

### Manual Deployment
1. Build the frontend: `cd rio-crm-frontend && pnpm run build`
2. Copy build files to backend static folder
3. Set environment variables for production
4. Start the Flask application

## 📝 API Documentation

The API provides the following endpoints:

- `GET /api/health` - Health check
- `POST /api/auth/login` - User authentication
- `GET /api/leads` - Get leads
- `GET /api/contacts` - Get contacts
- `GET /api/deals` - Get deals
- `GET /api/companies` - Get companies
- `GET /api/activities` - Get activities
- `GET /api/dashboard/overview` - Dashboard data

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.
EOF

    print_success "Documentation created"
}

# Main setup function
main() {
    echo "🔧 Rio CRM Setup Script"
    echo "======================="
    echo ""
    
    # Check if we're in the right directory
    if [ ! -d "rio-crm-backend" ] || [ ! -d "rio-crm-frontend" ]; then
        print_error "Rio CRM directories not found!"
        print_error "Please ensure you're in the root directory with both rio-crm-backend and rio-crm-frontend folders."
        exit 1
    fi
    
    # Run setup steps
    check_requirements
    setup_backend
    setup_frontend
    setup_database
    run_tests
    create_docs
    
    echo ""
    print_success "🎉 Rio CRM setup completed successfully!"
    echo ""
    echo "Next steps:"
    echo "  • Run './dev.sh' to start development servers"
    echo "  • Run './run.sh' to start production server"
    echo "  • Visit http://localhost:3000 for the frontend"
    echo "  • Visit http://localhost:5000/api/health for backend health check"
    echo ""
    echo "Default login credentials:"
    echo "  • Admin: admin@riocr.com / admin123"
    echo "  • Sales Rep: sales@riocr.com / sales123"
    echo "  • Manager: manager@riocr.com / manager123"
    echo ""
}

# Run main function
main "$@"

