#!/bin/bash

# Rio CRM Startup Script for Replit
echo "🚀 Starting Rio CRM Application..."

# Set environment variables
export PYTHONPATH="/home/runner/rio-crm/rio-crm-backend"
export FLASK_ENV="production"
export FLASK_DEBUG="False"
export HOST="0.0.0.0"
export PORT="5000"

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to install backend dependencies
install_backend_deps() {
    echo "📦 Installing backend dependencies..."
    cd rio-crm-backend
    
    # Create virtual environment if it doesn't exist
    if [ ! -d "venv" ]; then
        echo "Creating Python virtual environment..."
        python -m venv venv
    fi
    
    # Activate virtual environment
    source venv/bin/activate
    
    # Upgrade pip
    pip install --upgrade pip
    
    # Install dependencies
    if [ -f "requirements.txt" ]; then
        pip install -r requirements.txt
    else
        echo "⚠️  requirements.txt not found, installing basic dependencies..."
        pip install flask flask-sqlalchemy flask-cors pyjwt python-dotenv werkzeug
    fi
    
    cd ..
}

# Function to install frontend dependencies
install_frontend_deps() {
    echo "📦 Installing frontend dependencies..."
    cd rio-crm-frontend
    
    # Check if node_modules exists
    if [ ! -d "node_modules" ]; then
        echo "Installing Node.js dependencies..."
        if command_exists pnpm; then
            pnpm install
        elif command_exists npm; then
            npm install
        else
            echo "❌ Neither pnpm nor npm found!"
            exit 1
        fi
    else
        echo "✅ Frontend dependencies already installed"
    fi
    
    cd ..
}

# Function to build frontend
build_frontend() {
    echo "🏗️  Building frontend..."
    cd rio-crm-frontend
    
    if command_exists pnpm; then
        pnpm run build
    elif command_exists npm; then
        npm run build
    else
        echo "❌ Neither pnpm nor npm found!"
        exit 1
    fi
    
    # Copy built files to backend static folder
    if [ -d "dist" ]; then
        echo "📁 Copying built frontend to backend static folder..."
        mkdir -p ../rio-crm-backend/src/static
        cp -r dist/* ../rio-crm-backend/src/static/
        echo "✅ Frontend built and copied successfully"
    else
        echo "⚠️  Frontend build directory not found"
    fi
    
    cd ..
}

# Function to initialize database
init_database() {
    echo "🗄️  Initializing database..."
    cd rio-crm-backend
    source venv/bin/activate
    
    # Run database initialization
    python -c "
from src.main import app
from src.database.init_db import init_database
init_database(app)
print('✅ Database initialized successfully')
"
    
    cd ..
}

# Function to start the application
start_app() {
    echo "🌟 Starting Rio CRM backend server..."
    cd rio-crm-backend
    source venv/bin/activate
    
    # Start the Flask application
    python src/main.py
}

# Main execution flow
main() {
    echo "🔧 Rio CRM Setup and Startup"
    echo "=============================="
    
    # Check if we're in the right directory
    if [ ! -d "rio-crm-backend" ] || [ ! -d "rio-crm-frontend" ]; then
        echo "❌ Rio CRM directories not found!"
        echo "Please ensure you're in the root directory with both rio-crm-backend and rio-crm-frontend folders."
        exit 1
    fi
    
    # Install dependencies
    install_backend_deps
    install_frontend_deps
    
    # Build frontend
    build_frontend
    
    # Initialize database
    init_database
    
    # Start the application
    start_app
}

# Run main function
main "$@"

