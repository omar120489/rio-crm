# Rio CRM - Complete Project Structure

## 📁 Project Overview

Rio CRM is a modern, full-stack Customer Relationship Management system built with React and Flask, optimized for Replit deployment.

## 🏗️ Architecture

```
rio-crm/
├── 📁 rio-crm-backend/          # Flask Backend Application
│   ├── 📁 src/                  # Source code
│   │   ├── 📁 models/           # Database models and schemas
│   │   │   └── crm_models.py    # All CRM entities (User, Lead, Contact, etc.)
│   │   ├── 📁 routes/           # API route definitions
│   │   │   ├── auth.py          # Authentication endpoints
│   │   │   ├── leads.py         # Lead management endpoints
│   │   │   ├── contacts.py      # Contact management endpoints
│   │   │   ├── deals.py         # Deal pipeline endpoints
│   │   │   ├── companies.py     # Company management endpoints
│   │   │   ├── activities.py    # Activity tracking endpoints
│   │   │   ├── dashboard.py     # Analytics and dashboard endpoints
│   │   │   └── user.py          # User management endpoints
│   │   ├── 📁 database/         # Database utilities and configuration
│   │   │   ├── init_db.py       # Database initialization with seed data
│   │   │   ├── config.py        # Database configuration and utilities
│   │   │   └── migrate.py       # Database migration management
│   │   ├── 📁 static/           # Frontend build files (auto-generated)
│   │   └── main.py              # Application entry point
│   ├── 📁 venv/                 # Python virtual environment
│   ├── requirements.txt         # Python dependencies
│   ├── .env                     # Environment variables
│   └── .env.example             # Environment template
├── 📁 rio-crm-frontend/         # React Frontend Application
│   ├── 📁 src/                  # Source code
│   │   ├── 📁 components/       # React components
│   │   │   ├── Layout.jsx       # Main application layout
│   │   │   ├── ProtectedRoute.jsx # Route protection
│   │   │   └── theme-provider.jsx # Theme management
│   │   ├── 📁 pages/            # Page components
│   │   │   ├── LoginPage.jsx    # Authentication page
│   │   │   ├── DashboardPage.jsx # Analytics dashboard
│   │   │   ├── LeadsPage.jsx    # Lead management
│   │   │   ├── ContactsPage.jsx # Contact management
│   │   │   ├── DealsPage.jsx    # Deal pipeline
│   │   │   ├── CompaniesPage.jsx # Company management
│   │   │   └── ActivitiesPage.jsx # Activity tracking
│   │   ├── 📁 contexts/         # React contexts
│   │   │   └── AuthContext.jsx  # Authentication state
│   │   ├── 📁 lib/              # Utilities and API client
│   │   │   └── api.js           # API client configuration
│   │   └── App.jsx              # Main application component
│   ├── 📁 dist/                 # Built frontend files
│   ├── package.json             # Node.js dependencies
│   └── vite.config.js           # Build configuration
├── 📁 Deployment Configuration
│   ├── .replit                  # Replit environment configuration
│   ├── replit.nix               # Nix package configuration
│   ├── run.sh                   # Production startup script
│   ├── dev.sh                   # Development startup script
│   ├── setup.sh                 # Initial setup script
│   ├── Dockerfile               # Docker configuration
│   └── docker-compose.yml       # Docker Compose configuration
├── 📁 Documentation
│   ├── README.md                # Main project documentation
│   ├── rio_crm_analysis.md     # System analysis and requirements
│   └── todo.md                  # Development progress tracking
└── 📁 Configuration Files
    ├── .gitignore               # Git ignore rules
    └── .env                     # Global environment variables
```

## 🔧 Technology Stack

### Backend
- **Framework**: Flask (Python web framework)
- **Database**: SQLite with SQLAlchemy ORM
- **Authentication**: JWT (JSON Web Tokens)
- **CORS**: Flask-CORS for cross-origin requests
- **Environment**: python-dotenv for configuration

### Frontend
- **Framework**: React 18 with Vite
- **Styling**: Tailwind CSS + shadcn/ui components
- **Routing**: React Router v6
- **State Management**: React Context + React Query
- **Charts**: Recharts for data visualization
- **Icons**: Lucide React

### Development & Deployment
- **Environment**: Replit-optimized with Nix configuration
- **Package Managers**: pip (Python), pnpm (Node.js)
- **Build Tools**: Vite for frontend bundling
- **Containerization**: Docker support included

## 📊 Database Schema

### Core Entities

1. **Users** - System users with role-based access
   - Roles: Admin, Manager, Sales Rep, Support
   - Authentication with password hashing

2. **Companies** - Business accounts and organizations
   - Company details, revenue, employee count
   - Hierarchical relationships supported

3. **Contacts** - Individual contacts within companies
   - Personal information, job details
   - Primary contact designation

4. **Leads** - Potential customers in the sales funnel
   - Lead scoring, status tracking
   - Source attribution and assignment

5. **Deals** - Sales opportunities and pipeline
   - Value, probability, status tracking
   - Expected and actual close dates

6. **Activities** - Tasks, calls, meetings, emails
   - Scheduling and completion tracking
   - Associated with contacts and deals

7. **Products** - Service/product catalog
   - Pricing, categories, active status

### Relationships
- Users can be assigned leads and own deals
- Companies have multiple contacts
- Contacts can be associated with multiple deals
- Activities link to contacts and deals
- Full audit trail with created/updated timestamps

## 🚀 API Endpoints

### Authentication
- `POST /api/auth/login` - User authentication
- `POST /api/auth/logout` - User logout
- `POST /api/auth/refresh` - Token refresh

### Core Resources
- `GET|POST /api/leads` - Lead management
- `GET|POST /api/contacts` - Contact management
- `GET|POST /api/deals` - Deal pipeline
- `GET|POST /api/companies` - Company management
- `GET|POST /api/activities` - Activity tracking

### Analytics
- `GET /api/dashboard/overview` - Dashboard metrics
- `GET /api/dashboard/pipeline` - Sales pipeline data
- `GET /api/dashboard/activities` - Activity summaries
- `GET /api/dashboard/revenue-trends` - Revenue analytics

### System
- `GET /api/health` - Health check
- `GET /api/info` - API information

## 🎨 Frontend Architecture

### Component Structure
- **Layout Components**: Navigation, sidebar, header
- **Page Components**: Full-page views for each section
- **UI Components**: Reusable shadcn/ui components
- **Context Providers**: Authentication and theme management

### State Management
- **Authentication**: React Context for user state
- **API Data**: React Query for server state
- **Local State**: useState and useReducer for component state

### Routing
- Protected routes requiring authentication
- Role-based access control
- Dynamic navigation based on user permissions

## 🔐 Security Features

### Backend Security
- Password hashing with Werkzeug
- JWT token-based authentication
- CORS configuration for cross-origin requests
- Input validation and sanitization
- SQL injection prevention via ORM

### Frontend Security
- Protected routes with authentication checks
- Secure token storage and management
- XSS prevention through proper data handling
- HTTPS enforcement in production

## 📱 Responsive Design

### Breakpoints
- Mobile: < 768px
- Tablet: 768px - 1024px
- Desktop: > 1024px

### Adaptive Features
- Collapsible navigation on mobile
- Responsive data tables
- Touch-friendly interface elements
- Optimized layouts for all screen sizes

## 🧪 Testing Strategy

### Backend Testing
- Unit tests for models and utilities
- Integration tests for API endpoints
- Health check validation
- Database migration testing

### Frontend Testing
- Component unit tests
- Integration tests for user flows
- Build process validation
- Cross-browser compatibility

## 📈 Performance Optimizations

### Backend
- Database indexing for common queries
- Efficient SQLAlchemy queries
- Connection pooling
- Caching strategies (ready for Redis)

### Frontend
- Code splitting with Vite
- Lazy loading of components
- Optimized bundle size
- Image optimization
- Virtual scrolling for large datasets

## 🔄 Development Workflow

### Local Development
1. Run `./setup.sh` for initial setup
2. Use `./dev.sh` for development servers
3. Backend: http://localhost:5000
4. Frontend: http://localhost:3000

### Production Deployment
1. Run `./run.sh` for production server
2. Integrated frontend serving
3. Single port deployment (5000)

### Database Management
- Migration system with rollback support
- Seed data for development and testing
- Backup and restore utilities

## 🌐 Deployment Options

### Replit (Primary)
- Optimized configuration files
- Automatic environment setup
- One-click deployment

### Docker (Alternative)
- Multi-stage build process
- Production-ready container
- Docker Compose for orchestration

### Manual Deployment
- Detailed setup instructions
- Environment configuration
- Build and deployment scripts

## 📋 Default Data

### Test Users
- **Admin**: admin@riocr.com / admin123
- **Sales Rep**: sales@riocr.com / sales123
- **Manager**: manager@riocr.com / manager123
- **Support**: support@riocr.com / support123

### Sample Data
- 4 Companies with complete profiles
- 5 Contacts across different companies
- 4 Leads in various stages
- 4 Deals in the pipeline
- 5 Activities with different types

## 🔮 Future Enhancements

### Planned Features
- Email integration
- Calendar synchronization
- Advanced reporting
- Mobile application
- Third-party integrations

### Scalability Considerations
- PostgreSQL migration path
- Redis caching implementation
- Microservices architecture
- Load balancing strategies

## 📞 Support & Maintenance

### Monitoring
- Health check endpoints
- Error logging and tracking
- Performance metrics
- User activity analytics

### Backup Strategy
- Database backup utilities
- Configuration backup
- Automated backup scheduling
- Disaster recovery procedures

This comprehensive structure provides a solid foundation for a production-ready CRM system with room for future growth and enhancement.

