# Rio CRM Deployment Guide

## 🚀 Quick Start (Replit)

### Option 1: Direct Replit Import
1. **Import to Replit**:
   - Go to [Replit](https://replit.com)
   - Click "Create Repl"
   - Choose "Import from GitHub" or "Upload files"
   - Upload the Rio CRM project files

2. **Automatic Setup**:
   - Replit will detect the `.replit` and `replit.nix` files
   - Dependencies will be installed automatically
   - Click the "Run" button to start the application

3. **Access Your CRM**:
   - The application will be available at your Replit URL
   - Default login: `admin@riocr.com` / `admin123`

### Option 2: Manual Setup in Replit
1. **Create New Repl**:
   - Choose "Python" as the language
   - Upload all project files to the Repl

2. **Run Setup**:
   ```bash
   chmod +x setup.sh
   ./setup.sh
   ```

3. **Start Application**:
   ```bash
   ./run.sh
   ```

## 🔧 Local Development Setup

### Prerequisites
- Python 3.8+ 
- Node.js 16+
- npm or pnpm

### Step-by-Step Setup

1. **Clone/Download Project**:
   ```bash
   # If using git
   git clone <repository-url>
   cd rio-crm
   
   # Or extract downloaded files
   unzip rio-crm.zip
   cd rio-crm
   ```

2. **Run Automated Setup**:
   ```bash
   chmod +x setup.sh
   ./setup.sh
   ```

3. **Start Development Servers**:
   ```bash
   # Start both frontend and backend in development mode
   ./dev.sh
   ```

4. **Access Application**:
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:5000
   - Health Check: http://localhost:5000/api/health

### Manual Setup (If Automated Setup Fails)

#### Backend Setup
```bash
cd rio-crm-backend

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Set up environment
cp .env.example .env

# Initialize database
python -c "from src.main import app; from src.database.init_db import init_database; init_database(app)"

# Start backend
python src/main.py
```

#### Frontend Setup
```bash
cd rio-crm-frontend

# Install dependencies
npm install
# or
pnpm install

# Start development server
npm run dev
# or
pnpm run dev
```

## 🐳 Docker Deployment

### Using Docker Compose (Recommended)
```bash
# Build and start
docker-compose up --build

# Run in background
docker-compose up -d --build

# Stop services
docker-compose down
```

### Using Docker Directly
```bash
# Build image
docker build -t rio-crm .

# Run container
docker run -p 5000:5000 rio-crm
```

## ☁️ Cloud Deployment

### Heroku
1. **Prepare for Heroku**:
   ```bash
   # Create Procfile
   echo "web: cd rio-crm-backend && python src/main.py" > Procfile
   
   # Create requirements.txt in root
   cp rio-crm-backend/requirements.txt .
   ```

2. **Deploy**:
   ```bash
   heroku create your-app-name
   git add .
   git commit -m "Deploy to Heroku"
   git push heroku main
   ```

### Railway
1. **Connect Repository**:
   - Go to [Railway](https://railway.app)
   - Connect your GitHub repository
   - Railway will auto-detect the Python app

2. **Configure**:
   - Set start command: `cd rio-crm-backend && python src/main.py`
   - Add environment variables as needed

### DigitalOcean App Platform
1. **Create App**:
   - Go to DigitalOcean App Platform
   - Connect your repository
   - Configure build and run commands

2. **Build Settings**:
   - Build Command: `cd rio-crm-frontend && npm run build && cp -r dist/* ../rio-crm-backend/src/static/`
   - Run Command: `cd rio-crm-backend && python src/main.py`

## 🔧 Production Configuration

### Environment Variables
Create a `.env` file in the backend directory:

```env
# Production Settings
FLASK_ENV=production
FLASK_DEBUG=False
SECRET_KEY=your-super-secret-key-here
JWT_SECRET_KEY=your-jwt-secret-key-here

# Database (for PostgreSQL in production)
DATABASE_URL=postgresql://user:password@host:port/database

# Server Configuration
HOST=0.0.0.0
PORT=5000

# Security
CORS_ORIGINS=https://yourdomain.com

# Optional: Email Configuration
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password
```

### Database Migration to PostgreSQL

1. **Install PostgreSQL Dependencies**:
   ```bash
   pip install psycopg2-binary
   ```

2. **Update Database URL**:
   ```env
   DATABASE_URL=postgresql://username:password@host:port/database_name
   ```

3. **Run Migrations**:
   ```bash
   cd rio-crm-backend
   source venv/bin/activate
   python src/database/migrate.py migrate
   ```

### SSL/HTTPS Setup

For production, ensure HTTPS is enabled:

1. **Using Reverse Proxy (Nginx)**:
   ```nginx
   server {
       listen 443 ssl;
       server_name yourdomain.com;
       
       ssl_certificate /path/to/certificate.crt;
       ssl_certificate_key /path/to/private.key;
       
       location / {
           proxy_pass http://localhost:5000;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
       }
   }
   ```

2. **Using Let's Encrypt**:
   ```bash
   sudo certbot --nginx -d yourdomain.com
   ```

## 📊 Monitoring & Maintenance

### Health Checks
- **Endpoint**: `GET /api/health`
- **Expected Response**: `{"status": "healthy"}`

### Log Monitoring
```bash
# View application logs
tail -f rio-crm-backend/logs/app.log

# Monitor with Docker
docker-compose logs -f
```

### Database Backup
```bash
cd rio-crm-backend
source venv/bin/activate

# Create backup
python -c "from src.database.config import backup_database; backup_database()"

# Restore from backup
python -c "from src.database.config import restore_database; restore_database('backup_file.db')"
```

### Performance Monitoring
- Monitor response times for API endpoints
- Track database query performance
- Monitor memory and CPU usage
- Set up alerts for error rates

## 🔒 Security Checklist

### Pre-Production Security
- [ ] Change default secret keys
- [ ] Update default user passwords
- [ ] Enable HTTPS/SSL
- [ ] Configure CORS properly
- [ ] Set up rate limiting
- [ ] Enable security headers
- [ ] Regular dependency updates
- [ ] Database access restrictions
- [ ] Backup encryption
- [ ] Log monitoring

### Regular Maintenance
- [ ] Weekly dependency updates
- [ ] Monthly security patches
- [ ] Quarterly backup testing
- [ ] Annual security audit

## 🆘 Troubleshooting

### Common Issues

1. **Port Already in Use**:
   ```bash
   # Find process using port 5000
   lsof -i :5000
   
   # Kill process
   kill -9 <PID>
   ```

2. **Database Connection Issues**:
   ```bash
   # Reset database
   cd rio-crm-backend
   python -c "from src.main import app; from src.database.config import reset_database; reset_database(app)"
   ```

3. **Frontend Build Errors**:
   ```bash
   cd rio-crm-frontend
   rm -rf node_modules package-lock.json
   npm install
   npm run build
   ```

4. **Permission Issues**:
   ```bash
   chmod +x setup.sh dev.sh run.sh
   ```

### Getting Help
- Check the health endpoint: `/api/health`
- Review application logs
- Verify environment variables
- Test database connectivity
- Check network/firewall settings

## 📞 Support

For deployment issues or questions:
1. Check the troubleshooting section above
2. Review the project documentation
3. Verify all prerequisites are met
4. Test with the provided sample data

## 🔄 Updates & Upgrades

### Updating the Application
1. **Backup Current Data**:
   ```bash
   cd rio-crm-backend
   python -c "from src.database.config import backup_database; backup_database()"
   ```

2. **Update Code**:
   ```bash
   # Pull latest changes or replace files
   git pull origin main
   ```

3. **Update Dependencies**:
   ```bash
   # Backend
   cd rio-crm-backend
   source venv/bin/activate
   pip install -r requirements.txt
   
   # Frontend
   cd rio-crm-frontend
   npm install
   npm run build
   ```

4. **Run Migrations**:
   ```bash
   cd rio-crm-backend
   python src/database/migrate.py migrate
   ```

5. **Restart Application**:
   ```bash
   ./run.sh
   ```

This deployment guide covers all major deployment scenarios and provides comprehensive instructions for getting Rio CRM running in any environment.

