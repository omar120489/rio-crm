import { useQuery } from '@tanstack/react-query'
import { dashboardAPI } from '@/lib/api'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line
} from 'recharts'
import {
  Users,
  UserPlus,
  Building2,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Calendar,
  Target,
  Activity,
  AlertCircle
} from 'lucide-react'

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8']

export default function DashboardPage() {
  const { data: overview, isLoading: overviewLoading } = useQuery({
    queryKey: ['dashboard-overview'],
    queryFn: () => dashboardAPI.getOverview({ days: 30 }),
  })

  const { data: pipeline, isLoading: pipelineLoading } = useQuery({
    queryKey: ['dashboard-pipeline'],
    queryFn: () => dashboardAPI.getSalesPipeline(),
  })

  const { data: activities, isLoading: activitiesLoading } = useQuery({
    queryKey: ['dashboard-activities'],
    queryFn: () => dashboardAPI.getActivitySummary(),
  })

  const { data: leadFunnel, isLoading: funnelLoading } = useQuery({
    queryKey: ['dashboard-lead-funnel'],
    queryFn: () => dashboardAPI.getLeadFunnel({ days: 30 }),
  })

  const { data: revenueTrends, isLoading: revenueLoading } = useQuery({
    queryKey: ['dashboard-revenue-trends'],
    queryFn: () => dashboardAPI.getRevenueTrends({ months: 6 }),
  })

  if (overviewLoading) {
    return (
      <div className="space-y-6">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div className="h-4 bg-gray-200 rounded w-20 animate-pulse" />
                <div className="h-4 w-4 bg-gray-200 rounded animate-pulse" />
              </CardHeader>
              <CardContent>
                <div className="h-8 bg-gray-200 rounded w-16 animate-pulse mb-2" />
                <div className="h-3 bg-gray-200 rounded w-24 animate-pulse" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value)
  }

  const formatPercentage = (value) => {
    return `${value}%`
  }

  // Prepare pipeline data for charts
  const pipelineData = pipeline ? Object.entries(pipeline.pipeline).map(([stage, data]) => ({
    stage: stage.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase()),
    count: data.count,
    value: data.value,
    weighted_value: data.weighted_value
  })) : []

  // Prepare lead funnel data
  const funnelData = leadFunnel ? Object.entries(leadFunnel.funnel).map(([status, data]) => ({
    status: status.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase()),
    total: data.total,
    recent: data.recent
  })) : []

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Leads</CardTitle>
            <UserPlus className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overview?.totals?.leads || 0}</div>
            <p className="text-xs text-muted-foreground">
              +{overview?.recent?.leads || 0} this month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Contacts</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overview?.totals?.contacts || 0}</div>
            <p className="text-xs text-muted-foreground">
              +{overview?.recent?.contacts || 0} this month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(overview?.revenue?.total_revenue || 0)}
            </div>
            <p className="text-xs text-muted-foreground">
              Pipeline: {formatCurrency(overview?.revenue?.pipeline_value || 0)}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Win Rate</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatPercentage(overview?.deals?.win_rate || 0)}
            </div>
            <p className="text-xs text-muted-foreground">
              {overview?.deals?.won || 0} won, {overview?.deals?.lost || 0} lost
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts and Analytics */}
      <Tabs defaultValue="pipeline" className="space-y-4">
        <TabsList>
          <TabsTrigger value="pipeline">Sales Pipeline</TabsTrigger>
          <TabsTrigger value="leads">Lead Funnel</TabsTrigger>
          <TabsTrigger value="activities">Activities</TabsTrigger>
          <TabsTrigger value="revenue">Revenue Trends</TabsTrigger>
        </TabsList>

        <TabsContent value="pipeline" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Pipeline by Stage</CardTitle>
                <CardDescription>
                  Deal count and value by pipeline stage
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={pipelineData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="stage" 
                      angle={-45}
                      textAnchor="end"
                      height={80}
                    />
                    <YAxis />
                    <Tooltip 
                      formatter={(value, name) => [
                        name === 'value' ? formatCurrency(value) : value,
                        name === 'value' ? 'Total Value' : 'Deal Count'
                      ]}
                    />
                    <Bar dataKey="count" fill="#8884d8" name="count" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Pipeline Value Distribution</CardTitle>
                <CardDescription>
                  Total value by pipeline stage
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={pipelineData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ stage, value }) => `${stage}: ${formatCurrency(value)}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {pipelineData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => formatCurrency(value)} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Pipeline Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Pipeline Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <p className="text-sm font-medium">Total Pipeline Value</p>
                  <p className="text-2xl font-bold">
                    {formatCurrency(pipeline?.summary?.total_value || 0)}
                  </p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm font-medium">Weighted Pipeline</p>
                  <p className="text-2xl font-bold">
                    {formatCurrency(pipeline?.summary?.total_weighted_value || 0)}
                  </p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm font-medium">Total Deals</p>
                  <p className="text-2xl font-bold">
                    {pipeline?.summary?.total_deals || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="leads" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Lead Funnel</CardTitle>
                <CardDescription>
                  Lead distribution by status
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={funnelData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="status"
                      angle={-45}
                      textAnchor="end"
                      height={80}
                    />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="total" fill="#82ca9d" name="Total Leads" />
                    <Bar dataKey="recent" fill="#8884d8" name="Recent (30 days)" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Lead Metrics</CardTitle>
                <CardDescription>
                  Key performance indicators
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Conversion Rate</span>
                    <span className="text-sm text-muted-foreground">
                      {formatPercentage(leadFunnel?.conversion_rate || 0)}
                    </span>
                  </div>
                  <Progress value={leadFunnel?.conversion_rate || 0} className="h-2" />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Qualification Rate</span>
                    <span className="text-sm text-muted-foreground">
                      {formatPercentage(leadFunnel?.qualification_rate || 0)}
                    </span>
                  </div>
                  <Progress value={leadFunnel?.qualification_rate || 0} className="h-2" />
                </div>

                <div className="pt-4 space-y-2">
                  <p className="text-sm font-medium">Lead Sources</p>
                  {leadFunnel?.sources?.slice(0, 5).map((source, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-sm">{source.source || 'Unknown'}</span>
                      <Badge variant="secondary">{source.count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="activities" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Activity Overview</CardTitle>
                <CardDescription>
                  Your activity summary
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Completion Rate</p>
                    <p className="text-2xl font-bold">
                      {formatPercentage(overview?.activities?.completion_rate || 0)}
                    </p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Overdue</p>
                    <p className="text-2xl font-bold text-red-600">
                      {overview?.activities?.overdue || 0}
                    </p>
                  </div>
                </div>

                {activities?.type_summary && (
                  <div className="space-y-2">
                    <p className="text-sm font-medium">By Type</p>
                    {Object.entries(activities.type_summary).map(([type, data]) => (
                      <div key={type} className="flex items-center justify-between">
                        <span className="text-sm capitalize">{type.replace('_', ' ')}</span>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline">{data.completed}/{data.total}</Badge>
                          <span className="text-xs text-muted-foreground">
                            {data.total > 0 ? Math.round((data.completed / data.total) * 100) : 0}%
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Upcoming Activities</CardTitle>
                <CardDescription>
                  Next activities on your schedule
                </CardDescription>
              </CardHeader>
              <CardContent>
                {activities?.upcoming?.length > 0 ? (
                  <div className="space-y-3">
                    {activities.upcoming.slice(0, 5).map((activity) => (
                      <div key={activity.id} className="flex items-center space-x-3">
                        <div className="flex-shrink-0">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">
                            {activity.subject}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(activity.scheduled_at).toLocaleDateString()}
                          </p>
                        </div>
                        <Badge variant="outline" className="capitalize">
                          {activity.type.replace('_', ' ')}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">No upcoming activities</p>
                )}
              </CardContent>
            </Card>
          </div>

          {activities?.overdue?.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <AlertCircle className="h-5 w-5 text-red-500" />
                  <span>Overdue Activities</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {activities.overdue.slice(0, 5).map((activity) => (
                    <div key={activity.id} className="flex items-center space-x-3 p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">
                          {activity.subject}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Due: {new Date(activity.scheduled_at).toLocaleDateString()}
                        </p>
                      </div>
                      <Badge variant="destructive" className="capitalize">
                        {activity.type.replace('_', ' ')}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="revenue" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Revenue Trends</CardTitle>
              <CardDescription>
                Monthly revenue over the last 6 months
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={revenueTrends?.monthly_revenue || []}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis tickFormatter={(value) => formatCurrency(value)} />
                  <Tooltip 
                    formatter={(value) => [formatCurrency(value), 'Revenue']}
                    labelFormatter={(label) => `Month: ${label}`}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="revenue" 
                    stroke="#8884d8" 
                    strokeWidth={2}
                    dot={{ fill: '#8884d8' }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Total Revenue</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">
                  {formatCurrency(revenueTrends?.summary?.total_revenue || 0)}
                </p>
                <p className="text-sm text-muted-foreground">
                  {revenueTrends?.summary?.total_deals || 0} deals closed
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Average Deal Size</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">
                  {formatCurrency(revenueTrends?.summary?.avg_deal_size || 0)}
                </p>
                <p className="text-sm text-muted-foreground">
                  Per closed deal
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Growth Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-2">
                  <p className="text-2xl font-bold">
                    {formatPercentage(revenueTrends?.summary?.revenue_growth || 0)}
                  </p>
                  {(revenueTrends?.summary?.revenue_growth || 0) >= 0 ? (
                    <TrendingUp className="h-4 w-4 text-green-500" />
                  ) : (
                    <TrendingDown className="h-4 w-4 text-red-500" />
                  )}
                </div>
                <p className="text-sm text-muted-foreground">
                  Month over month
                </p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

